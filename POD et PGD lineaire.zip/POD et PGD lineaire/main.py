# -*- coding: utf-8 -*-
"""
Created on Wed Feb  8 20:57:14 2023

@author: antho
"""

from Maillage import Mesh,Triangles
from Equation import EDPsca
from Resolution import PGD,POD
from Source import diffusion2,diffusion3
from Traitement import PostTraitement,PostTraitement_POD
import numpy as np

###################################################################################
"""
Main du Projet. Il permet d'exécuter les différentes méthodes de calculs.
"""
###################################################################################
"""
PRE-TRAITEMENT (A COMPILER UNE SEULE FOIS)
"""
# Récupération du maillage et précalcul 
Maill = Mesh("MySquare.msh")
Tri = Triangles(Maill)
PC = Tri.PreCalcul()
# Définition de l'équation aux dérivées partielles 
EquChaleur = EDPsca()
EquChaleur.C1 = 1.0
EquChaleur.C2 = 1.0
EquChaleur.Operateur = "LaplacienScalaire"
# Création des matrices de masse et de rigidité
M = EquChaleur.Masse(Tri,PC)
K = EquChaleur.Rigidité(Tri,PC)
###################################################################################

"""
                                                    Méthode POD 
"""
"""
Définition des paramètres pour la méthode POD
"""
Tf=1.5
Nbr=2500
pas=Tf/(Nbr-1)
snaps=[5,10,20,30,40,100]    
tol_proj=1e-14
a0=np.zeros(Tri.Nn)
a0=a0[Tri.Nn-Tri.NnWOb:Tri.Nn]
Srce = diffusion2(Maill,Tf,Nbr,EquChaleur.C1,EquChaleur.C2)
Srce.val = Srce.Crop(Srce.val,Tri)
###################################################################################
"""
PROPER ORTHOGONAL DECOMPOSITION (POD)
"""
PTpod = PostTraitement_POD(Srce.NameSource, snaps)
for m in snaps:
    RES = POD(Tri.NnWOb,Tf,Nbr,m,tol_proj)
    RES.calcul(Tri, PC, Srce.val, K, M, a0, m)
    PTpod.RecupInfoPOD(RES)
###################################################################################
"""
POST-TRAITEMENT (POD)
"""
PTpod.AddBoundary(Tri)
PTpod.SolAnalytique(1,Maill,Nbr,Tf)
PTpod.Erreur()
PTpod.Affichage(Maill,Tf,Nbr)
PTpod.Analy_plot(PTpod.SolAnaly, Maill, Nbr)
for i in range (len(snaps)):
    PTpod.solution_plot(PTpod.Sol[i], Maill, Nbr,snaps[i])

###################################################################################
"""
                                                Méthode PGD
"""    
"""
Définition des paramètres pour la méthode PGD
"""
# #Paramètres de calcul
# TfinPGD = 1.5
# NtempsPGD = 1500
# ModePGD = [1,2,3,4,5,6]
# MaxIterPGD = 300
# TolPGD = 1e-13
# ModesSource = 4 # Seulement pour diffusion3
# # Création de la source
# # Srce = diffusion3(ModesSource,Maill,TfinPGD,NtempsPGD,EquChaleur.C1,EquChaleur.C2)
# # Srce.val = Srce.Crop(Srce.val,Tri)
# Srce = diffusion2(Maill,TfinPGD,NtempsPGD,EquChaleur.C1,EquChaleur.C2)
# Srce.val = Srce.Crop(Srce.val,Tri)

# ###################################################################################
# """
# PROPER GENERALIZED DECOMPOSITION (PGD)
# """
# PTpgd = PostTraitement(Srce.NameSource,ModePGD)
# for Mode in ModePGD:
#     RES = PGD(Tri.NnWOb,TfinPGD,NtempsPGD,Mode,MaxIterPGD,TolPGD)
#     RES.Calcul(Srce.val,K,M,EquChaleur.C1,EquChaleur.C2)
#     PTpgd.RecupInfoPGD(RES)
# ###################################################################################
# """
# POST-TRAITEMENT (PGD)
# """
# PTpgd.AssemblageModePGD()
# PTpgd.AddBoundary(Tri)
# PTpgd.SolAnalytique(ModesSource,Maill,NtempsPGD,TfinPGD)
# PTpgd.Erreur()
# PTpgd.Affichage(Maill,TfinPGD,NtempsPGD)
# PTpgd.Analy_plot(PTpgd.Sol, Maill, NtempsPGD)
# for i in range (len(ModePGD)):
#     PTpgd.solution_plot(PTpgd.Ttot[i], Maill, NtempsPGD,ModePGD[i])