import numpy as np
from Utile import  Triplet
from scipy.sparse import coo_matrix
from time import process_time
from scipy import linalg
from scipy.sparse.linalg import spsolve
# from LaplaceTransformMatrix import *

class AKP:
   def __init__(self, fexp, m, N_w, N_temps,NnWOb,Tfin):
       """
       Description
       ----------
       Classe permettant d'utiliser la méthode AKP( Krylov_Projection_method).
       
       Parameters
       ----------
       Ns : int
           Le nombre de pas de temps pris en compte (snapshot) pour le calcul 
           de la solution non réduite As.
       Returns
       -------
       None.
       """
       self.fexp = fexp
       self.N_w = N_w
       self.m = m
       w0 = 2*np.pi*fexp
       w_sweep = np.linspace(0.1, 100*w0, N_w)
       self.w_sweep = w_sweep
       self.N_temps = N_temps
       
       self.NnWOb = NnWOb
       self.Tfin = Tfin
       self.dt = self.Tfin/float(self.N_temps-1)
       
   

   def arnoldi1(self, A, b, n):
       """Computes a basis of the (n + 1)-Krylov subspace of A: the space
       spanned by {b, Ab, ..., A^n b}.

       Arguments
         A: m × m array
         b: initial vector (length m)
         n: dimension of Krylov subspace, must be >= 1
       
       Returns
         Q: m x (n + 1) array, the columns are an orthonormal basis of the
           Krylov subspace.
         h: (n + 1) x n array, A on basis Q. It is upper Hessenberg.  
       """
       eps = 1e-12
       h = np.zeros((n+1,n))
       Q = np.zeros((A.shape[0],n+1))
        # Normalize the input vector
       Q[:,0] = b / np.linalg.norm(b,2)   # Use it as the first Krylov vector
       for k in range(1,n+1):
           v = np.dot(A, Q[:,k-1])  # Generate a new candidate vector
           for j in range(k):  # Subtract the projections on previous vectors
               h[j,k-1] = np.dot(Q[:,j].T, v)
               v = v - h[j,k-1] * Q[:,j]
           h[k,k-1] = np.linalg.norm(v,2)
           if h[k,k-1] > eps:  # Add the produced vector to the list, unless
               Q[:,k] = v/h[k,k-1]
           else:  # If that happens, stop iterating.
               return Q
       return Q
   
   def arnoldi2(self,G, g, m):
    """
    Implementation de l'algorithm Arnoldi '
    Returns: la base orthonormale de l'espace de Krylov: [g, Gg, ..., G^{m-1}g].
    """
    n = len(g)
    Q = np.zeros((n, m+1))
    H = np.zeros((m+1, m))

    # Normalize the initial vector g and store it in the first column of Q
    Q[:, 0] = g / np.linalg.norm(g)

    for j in range(m):
        # Compute the j-th column of Q and the j-th row of H
        v = G @ Q[:, j]
        for i in range(j+1):
            H[i, j] = np.dot(Q[:, i], v)
            v -= H[i, j] * Q[:, i]
        H[j+1, j] = np.linalg.norm(v)
        Q[:, j+1] = v / H[j+1, j]

    return Q[:, :-1]
         
   def Proj_Krylov(self, M, K, f, m):
        """
        Parameters
        ----------
        M : sparse([NnWOb,NnWOb])
            Matrice de masse.
        K : sparse([NnWOb,NnWOb])
            Matrice de rigidité.
        F : TYPE
            DESCRIPTION.
        f : float
            fréquence du fondamental.
        m : int
            nombre d'itératons d'Arnoldi.
            Nombre de vecteurs de la famille génératrice de Krylov
        Returns
        -------
        P : TYPE
            DESCRIPTION.
        """
        Marray = M.toarray()
        n =np.shape(Marray)
        s = 2 * np.pi * f
        g = np.linalg.inv(M.toarray()*s+K.toarray())@np.array([1 for i in range(n[0])])
        G = -1 * np.linalg.inv(M.toarray()*s+K.toarray()) @ M
        P = self.arnoldi2(G, g, m) 
        return P
    
   def AKP_matrices(self, M, K, F, f, m):
        """ 
        Parameters
        ----------
        M : TYPE
            DESCRIPTION.
        K : TYPE
            DESCRIPTION.
        F : TYPE
            DESCRIPTION.
        f : TYPE
            DESCRIPTION.
        m : TYPE
            DESCRIPTION.
        Returns
        -------
        matrice_reduite : TYPE
            DESCRIPTION.
        """
        P = self.Proj_Krylov(M, K, f, m)
        Marray = M.toarray()
        n =np.shape(Marray)
        Mr = np.transpose(P)@M.toarray()@P
        Kr = np.transpose(P)@K.toarray()@P
        Fr = np.transpose(P)@F
        return (Mr,Kr,Fr) 
   
   # def Assemblage_sol(self, Mr, Kr, Fr, S, w_sweep):
   #     '''
   #     Parameters
   #     ----------
   #     Mr : TYPE
   #         DESCRIPTION.
   #     Kr : TYPE
   #         DESCRIPTION.
   #     Fr : TYPE
   #         DESCRIPTION.
   #     S : Vecteur
   #         Matrice de dimensions (Nbr Noeuds, Nombre de fréquences du sweep).
   #     w_sweep : vecteur colonne
   #         DESCRIPTION.
   #     Returns
   #     -------
   #     None.
   #     ''' 
   #     m = len(Fr)
   #     n = len(w_sweep)
   #     Xt=[[0 for j in range(m)] for k in range(n)]
   #     # St=np.transpose(S)
   #     for i in range(n):
   #         w = w_sweep[i]
   #         coeff = w*1.j
   #         A_w = np.linalg.inv(coeff*Mr + Kr)@Fr
   #         # print('shape A_w', np.shape(A_w))
   #         X_w = S[i]*A_w
   #         Xt[i]=X_w
   #     X = np.transpose(Xt)
   #    return X
   
 
   def solve_reduc(self,Kr,Mr,Fr,ar0,Tf,pas,P):
        """
        Description
        -----------
        Résolution du système réduit avec la méthode d'Euler et le calcul de 
        la solution du problème initial

        Parameters
        ----------
        Kr : array([r,r])
            Matrice de rigidité.
        Mr : array([r,r])
            Matrice de masse.
        Fr : array([r,Ntemps])
            Matrice telle que ces chaque colonne correspond au second membre du
            système pour un instant donné ( t(i)=i.pas pour i=0 à Ntemps-1 ).
        ar0 : array([r])
            Condition initiale du problème réduit, elle est exprimée en fonction
            de la condition initiale du problème initial tel que: 
                ar0 = transpose(P).a0 
        T : int
            Temps final.
        pas : float
            le pas du schéma d'Euler. pas= Tfin/(Ntemps-1)
        P : array([NnWOb,r]) 
            avec r est la taille réduite du problème

        Returns
        -------
        Ad : array([NnWOb,Ntemsp])
            Solution du Problème initial.

        """
        Ar=np.zeros((Kr.shape[0],self.N_temps))
        Ar.T[0]=ar0
        for i in range (self.N_temps-1):
            #sec_membre=Fr.T[i]-Kr@Ar.T[i]
            sec_membre=Fr.T[i+1]+1/pas*Mr@Ar.T[i]
            #dAdt=spsolve(Mr,sec_membre.T)
            Ar.T[i+1]=spsolve(1/pas*Mr+Kr,sec_membre.T)
            #Ar.T[i+1]=Ar.T[i]+pas*dAdt
        Ad=P@Ar    
        return Ad
   
   def calcul(self,Triangles,PreCalcul,source,K,M,f,a0,m):
        """
        Description
        -----------
        Procédure de la méthode POD

        Parameters
        ----------
        Triangles : Type Triangles
            Cette classe permet de récupérer les informations des triangles du maillage..
        PreCalcul : Liste
            Liste de Tuple contenant différents calculs pour chaque triangle.
        source : array([Nn,Ntemps])
            Matrice contenant les valeurs de la source pour chaque noeuds pour
            chaque pas de temps.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        a0 : array([NnWOb])
            Condition initiale du schéma d'Euler.
        m : int
            le nombre de Snapshot.

        Returns
        -------
        T : array([Nn,Ntemps])
            Solution du problème: une matrice qui contient les valeurs de la
            solution pour chaque noeuds pour chaque pas de temps.

        """
        ti=process_time()
        F = M.toarray()@source
        P=self.Proj_Krylov(M, K, f,m)
        MATRIX=self.AKP_matrices(K, M, F, f, m)
        Mr= MATRIX[0]
        Kr=MATRIX[1]
        Fr=MATRIX[2]
        ar0=P.T@a0
        self.TailleReduc = P.shape
        Ad=self.solve_reduc(Kr, Mr, Fr, ar0, self.Tfin, self.dt, P)
        self.TpsCalcul=process_time()-ti
        self.sol=Ad
        
    
   def AddBoundary(self,Tri,N_w,T,Boundary = 0):
       """
       Description
       ----------
       Cette méthode ajoute les bords dans la matrice de la solution.

       Parameters
       ----------
       Tri : Class
           Objet de classe Triangles.
       T : array([NnWOb,Nw])
           Matrice des résultats du calcul (sans les bords).
       Boundary : float, optional
           Valeur sur les bords (conditions de type Dirichlet). Par défaut, c'est 0.

       Returns
       -------
       Ttot : array([Nn,Ntemps])
           Matrice des résultats du calcul (avec les bords).
       """
       Ttot = Boundary*np.ones([Tri.Nn,N_w])
       for i in range(N_w):
           Ttot[Tri.Nn-Tri.NnWOb:Tri.Nn,i] = T[:,i]
       return Ttot
   
  
      