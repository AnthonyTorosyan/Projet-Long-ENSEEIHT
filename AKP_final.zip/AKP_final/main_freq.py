
import numpy as np
from scipy.sparse import coo_matrix
from scipy import linalg
from scipy.sparse.linalg import *
import matplotlib.pyplot as plt

from Maillage import *
from Equation import *
from AKP import *
from Source import *
from Traitement import *
# from plot_dynamique_POD import *

# Récupération du maillage et précalcul 
Maill = Mesh("MySquare.msh")
Tri = Triangles(Maill)
PC = Tri.PreCalcul()
# Définition de l'équation aux dérivées partielles 
EquChaleur = EDPsca()
EquChaleur.C1 = 1.0
EquChaleur.C2 = 1.0
EquChaleur.Operateur = "LaplacienScalaire"
# Création des matrices de masse et de rigidité
M = EquChaleur.Masse(Tri,PC)
K = EquChaleur.Rigidité(Tri,PC)
###################################################################################
fexp = 0.0001 # fréquence de la fondamentale
m = 100 # nombre d'itératons d'Arnoldi
N_w = 100
N_temps = 100
Tf = 1
Nbr = 100


a0=np.zeros(Tri.Nn)
a0=a0[Tri.Nn-Tri.NnWOb:Tri.Nn]


#Srce = diffusion2(Maill,Tf,Nbr,EquChaleur.C1,EquChaleur.C2)
Srce = diffusion3(5,Maill,Tf,Nbr,EquChaleur.C1,EquChaleur.C2)
Srce.val = Srce.Crop(Srce.val,Tri)

PTakp = PostTraitement_AKP(Srce.NameSource, [m])
for mm in [m]:
    RES = AKP(fexp, mm, N_w, N_temps,Tri.NnWOb,Tf)
    RES.calcul(Tri, PC, Srce.val, K, M, fexp, a0, mm)
    PTakp.RecupInfoAKP(RES)
print(RES.sol)
"""
POST-TRAITEMENT (POD)
"""
PTakp.AddBoundary(Tri)
PTakp.SolAnalytique(5,Maill,Nbr,Tf)
PTakp.Erreur()
PTakp.Affichage(Maill,Tf,Nbr)
PTakp.Analy_plot(PTakp.SolAnaly, Maill, Nbr)
snaps =[m]
for i in range (len(snaps)):
    PTakp.solution_plot(PTakp.Sol[i], Maill, Nbr, snaps[i])




#add_boudaries
Ttot = RES.AddBoundary(Tri,N_w,RES.sol,Boundary = 0)

