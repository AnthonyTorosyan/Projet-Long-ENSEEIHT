import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
from numpy.linalg import norm

class PostTraitement_AKP:
    def __init__(self,NameSource,m):
        """
        Description
        ----------
        Cette classe est consacrée au post-traitement de la méthode POD.
        Parameters
        ----------
        NameSource : Chaîne de caractères
        Nom de la source utilisée.
        Modes : Liste
        Liste contenant le nombre de Snapshots utilisé pour chaque simulation.
        Returns
        -------
        None.
        """
        self.methode="AKP"
        self.NameSource = NameSource
        self.m = m
        self.NbrSimu = len(m)
        self.SolWOb = []
        self.Sol = []
        self.SolAnaly = []
        self.Err = []
        self.TpsCalcul = []
        self.InfoReduc = []
    def RecupInfoAKP(self,RES):
        self.SolWOb.append(RES.sol)
        self.TpsCalcul.append(RES.TpsCalcul)
        self.InfoReduc.append(RES.TailleReduc)
    def result_plot(self,Ad,Maill,t):
        """
        Description
        ----------
        Méthode permettant de tracer les graphes.
        Parameters
        ----------
        Ad : array([Nn,Ntemps])
        Matrice de la solution calculée.
        Maill : Class
        Objet de classe Maillage.
        t : int
        Itération temporelle affichée par le graphe.
        Returns
        -------
        None.
        """
        triang = mtri.Triangulation(Maill.x, Maill.y)
        fig = plt.figure()
        ax = fig.add_subplot(1,1,1, projection='3d')
        ax.plot_trisurf(triang, Ad.T[t], cmap='jet')
        ax.scatter(Maill.x,Maill.y,Ad.T[t], marker='.', s=10, c="black", alpha=0.5)
        ax.view_init(elev=60, azim=-45)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('T')
        plt.show()
    def solution_plot(self,Ad,Maill,Ntemps,snaps):
        """
        Description
        ----------
        Méthode permettant de tracer les graphes de la solution dans une seule 
        figure.
        Parameters
        ----------
        Ad : array([Nn,Ntemps])
        Matrice de la solution calculée.
        Maill : Class
        Objet de classe Maillage.
        Ntemps : integer 
        Nombre de pas de temps
        snaps: integer 
        nombre de snapshots
        Returns
        -------
        None.
        """        
        triang = mtri.Triangulation(Maill.x, Maill.y)
        fig = plt.figure(figsize=np.array([15,10]))
        ttl="Solution avec {0} pour la source {1}, un maillage de {2} noeuds et {3} de snapshots".format(self.methode,self.NameSource,np.shape(Ad)[0],snaps)
        fig.suptitle(ttl)
        for i in range(5):
            
            ax = fig.add_subplot(2, 3, i+1, projection='3d')
            ax.plot_trisurf(triang, Ad.T[int(i*Ntemps/5)], cmap='jet')
            ax.scatter(Maill.x,Maill.y,Ad.T[int(i*Ntemps/5)], marker='.', s=10, c="black", alpha=0.5)
            ax.view_init(elev=60, azim=-45)
            ax.set_xlabel('X')
            ax.set_ylabel('Y')
            ax.set_zlabel('T')
            ax.set_title("Solution à t=i*T/5 pour i={0}".format(i))

        ax = fig.add_subplot(2, 3, 6, projection='3d')
        ax.plot_trisurf(triang, Ad.T[-1], cmap='jet')
        ax.scatter(Maill.x,Maill.y,Ad.T[-1], marker='.', s=10, c="black", alpha=0.5)
        ax.view_init(elev=60, azim=-45)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('T')
        ax.set_title("Solution à t=i*T/5 pour i=5") 
        
        plt.show()    
    def Analy_plot(self,Ad,Maill,Ntemps):
        """
        Description
        ----------
        Méthode permettant de tracer les graphes de la solution analytique dans 
        une seule figure.
        Parameters
        ----------
        Ad : array([Nn,Ntemps])
        Matrice de la solution calculée.
        Maill : Class
        Objet de classe Maillage.
        Ntemps : integer
        nombre de pas de temps
        Returns
        -------
        None.
        """        
        triang = mtri.Triangulation(Maill.x, Maill.y)
        fig = plt.figure(figsize=np.array([15,10]))
        ttl="Solution analytique pour la source {0}, un maillage de {1} noeuds".format(self.NameSource,np.shape(Ad)[0])
        fig.suptitle(ttl)
        for i in range(5):
            
            ax = fig.add_subplot(2, 3, i+1, projection='3d')
            ax.plot_trisurf(triang, Ad.T[int(i*Ntemps/5)], cmap='jet')
            ax.scatter(Maill.x,Maill.y,Ad.T[int(i*Ntemps/5)], marker='.', s=10, c="black", alpha=0.5)
            ax.view_init(elev=60, azim=-45)
            ax.set_xlabel('X')
            ax.set_ylabel('Y')
            ax.set_zlabel('T')
            ax.set_title("Solution à t=i*T/5 pour i={0}".format(i))

        ax = fig.add_subplot(2, 3, 6, projection='3d')
        ax.plot_trisurf(triang, Ad.T[-1], cmap='jet')
        ax.scatter(Maill.x,Maill.y,Ad.T[-1], marker='.', s=10, c="black", alpha=0.5)
        ax.view_init(elev=60, azim=-45)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('T')
        ax.set_title("Solution à t=i*T/5 pour i=5") 
        
        plt.show()            
    def AddBoundary(self,Tri,Boundary = 0):
        """
        Description
        ----------
        Cette méthode ajoute les bords dans la matrice de la solution.

        Parameters
        ----------
        Tri : Class
        Objet de classe Triangles.
        Boundary : float, optional
        Valeur sur les bords (conditions de type Dirichlet). Par défaut, c'est 0.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            T = self.SolWOb[i]
            Ntemps = np.shape(T)[1]
            Twb = Boundary*np.ones([Tri.Nn,Ntemps])
            for j in range(Ntemps):
                Twb[Tri.Nn-Tri.NnWOb:Tri.Nn,j] = T[:,j]
            self.Sol.append(Twb)
    def SolAnalytique(self,M,Maill,Ntemps,Tfin):
        """
        Description
        ----------
        Calcul de la solution analytique de l'EDP.

        Parameters
        ----------
        M : int
        Nombre de modes pour la solution Diffusion3.
        Maill : Class
        Objet de classe Maillage.
        Ntemps : int
        Nombre de points dans la discrétisation temporelle.
        Tfin : float
        Temps final.

        Returns
        -------
        None.
        """
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        Y = Maill.y
        if self.NameSource == "Diffusion2":
            self.SolAnaly = (np.tensordot(np.sin(2*np.pi*(X-1))*np.sin(2*np.pi*(Y-1)),np.sin(np.pi*t),axes=0))
        if self.NameSource == "Diffusion3":
            Nn = int(np.max(Maill.Noeuds))
            self.SolAnaly = np.zeros([Nn,Ntemps])
            for m in range(M):
                self.SolAnaly = self.SolAnaly+np.tensordot(np.sin(2*np.pi*(X-1))*np.sin(2*np.pi*(Y-1))*np.cos(2*np.pi*m/M*X)*np.cos(2*np.pi*m/M*Y),np.sin(np.pi*t)*np.cos(2*np.pi*m/M*t),axes=0)
        if self.NameSource == "NonLinéairePGDexp" or self.NameSource == "NonLinéairePGDquadratique":
            self.SolAnaly = np.tensordot(X*(1-X)*Y*(1-Y),t,axes=0)  
    def Erreur(self):
        """
        Description
        ----------
        Cette méthode permet de calculer l'erreur relative entre les solutions 
        calculée et analytique pour chaque pas de temps.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            Err_i = []
            Ttot_i = self.Sol[i]
            Ntemps = np.shape(Ttot_i)[1]
            for j in range(Ntemps):
                Err_i.append(norm(Ttot_i[:,j]-self.SolAnaly[:,j],2)/(1+norm(self.SolAnaly[:,j],2)))
            self.Err.append(Err_i)
    def Affichage(self,Maill,Tfin,Ntemps):
        """
        Description
        ----------
        Affichage du temps de calcul, et des informations sur l'erreur relative pour chaque simulation.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            print('----------------------------------------------------',end='\n')
            print('------------- NOMBRE DE SNAPSHOTS: '+str(self.m[i])+' -------------------',end='\n')
            print('----------------------------------------------------',end='\n \n')
            print('Temps de calcul', self.TpsCalcul[i],end='\n \n')
            print('La taille du problème initial est:',self.InfoReduc[i][0],end='\n \n')
            print('La taille du problème réduit est:',self.InfoReduc[i][1],end='\n \n')
            print("Minimum de l'erreur relative",np.min(self.Err[i][1:]),end='\n')
            print("Moyenne de l'erreur relative",np.mean(self.Err[i]),end='\n')
            print("Maximum de l'erreur relative",np.max(self.Err[i]),end='\n \n')
        if self.NbrSimu > 1:
            MeanErr = np.zeros(self.NbrSimu)
            for i in range(self.NbrSimu):
                MeanErr[i] = np.mean(self.Err[i][:])
            fig,ax = plt.subplots()
            ax.plot(self.m,MeanErr,"k:o")
            ax.set_xlabel("Nombre de Snapshots")
            ax.set_ylabel("Erreur relative moyenne")
            ax.set_title("Erreur en fonction du nombre de Snapshots")
            plt.grid()
            plt.show()            
