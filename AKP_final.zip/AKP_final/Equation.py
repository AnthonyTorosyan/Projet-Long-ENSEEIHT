from Utile import Triplet
import numpy as np
from scipy.sparse import coo_matrix
        
class EDPsca:
    def __init__(self):
        """
        Description
        -------
        Création d'une EDP scalaire de la forme C1*dt(T)+C2*Operateur(T) = s(x,t)
        avec dt() la dérivée temporelle.

        Returns
        -------
        None.
        """
        self.Operateur = ""
        self.C1 = float()
        self.C2 = float()
    def Masse(self,Triangles,PreCalcul):
        """
        Description
        ----------
        Assemblage de la matrice de masse.
        Parameters
        ----------
        Triangles : Class
            Objet de classe Triangles contenant les informations des triangles.
        PreCalcul : Liste
            Liste de Tuples contenant le précalcul de différents éléments des Triangles.
            
        Returns
        -------
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        """
        # Récupération des informations du maillage
        Tri = Triangles.Tri
        Nt = Triangles.Nt
        Nn = Triangles.Nn
        NnWOb = Triangles.NnWOb
        # Instanciation d'un Triplet
        t = Triplet()
        if self.Operateur == "LaplacienScalaire":
            for p in range(Nt):
                T = Tri[p]
                PC = PreCalcul[p]
                # Matrice de masse M élémentaire
                Melm = PC[3]/12*np.array([[2,1,1],[1,2,1],[1,1,2]])
                for i in range(3):
                    I = int(T[i][0]-1)
                    for j in range(3):
                        J = int(T[j][0]-1)
                        t.append(I,J,Melm[i,j])
            M = coo_matrix(t.data)
            # On coupe la partie où il y a les bords
            CropR = Triplet()
            j = 0
            for i in range(Nn-NnWOb,Nn):
                CropR.append(i,j,1)
                j = j+1
            CropRight = coo_matrix(CropR.data)
            M = np.transpose(CropRight)@M@CropRight
            return M
    def Rigidité(self,Triangles,PreCalcul):
        """
        Description
        ----------
        Assemblage de la matrice de rigidité.

        Parameters
        ----------
        Triangles : Class
            Objet de classe Triangles contenant les informations des triangles.
        PreCalcul : Liste
            Liste de Tuples contenant le précalcul de différents éléments des Triangles.

        Returns
        -------
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        """
        # Récupération des informations du maillage
        Tri = Triangles.Tri
        Nt = Triangles.Nt
        Nn = Triangles.Nn
        NnWOb = Triangles.NnWOb
        # Instanciation d'un Triplet
        t = Triplet()
        if self.Operateur == "LaplacienScalaire":
            for p in range(Nt):
                T = Tri[p]
                PC = PreCalcul[p]
                # Matrice de rigidité K élémentaire
                K22 = PC[0]/4/PC[3]
                K33 = PC[1]/4/PC[3]
                K23 = PC[2]/4/PC[3]
                Kelm = np.array([[K22+K33+2*K23,-K23-K22,-K23-K33],[-K23-K22,K22,K23],[-K23-K33,K23,K33]])
                for i in range(3):
                    I = int(T[i][0]-1)
                    for j in range(3):
                        J = int(T[j][0]-1)
                        t.append(I,J,Kelm[i,j])
            K = coo_matrix(t.data)
            # On coupe la partie où il y a les bords
            CropR = Triplet()
            j = 0
            for i in range(Nn-NnWOb,Nn):
                CropR.append(i,j,1)
                j = j+1
            CropRight = coo_matrix(CropR.data)
            K = np.transpose(CropRight)@K@CropRight
            return K
        
    
    

            
            
            
    

        
       
            
       
                
        
