import numpy as np
import gmsh
from numpy.linalg import norm

class Mesh:
    def __init__(self,NomFichier):
        """
        Description
        ----------
        Récupération des informations du maillage gmsh.

        Parameters
        ----------
        NomFichier : Chaîne de caractères
            Nom du fichier définissant le maillage.

        Returns
        -------
        None.
        """
        self.NomFichier = NomFichier
        # Initialiser GMSH
        gmsh.initialize()
        # Charger un fichier .msh
        gmsh.open(NomFichier)
        # Récupérer les noeuds et coordonnées pour chaque triangle
        GetAll = gmsh.model.mesh.getNodesByElementType(2)
        self.Noeuds = GetAll[0]
        self.Coord = GetAll[1]
        # Récupérer les noeuds qui ne sont pas au bord
        GetNotBoundary = gmsh.model.mesh.getNodes(2,includeBoundary=False)
        self.NoeudsNotBoundary = GetNotBoundary[0]
        # Finaliser GMSH
        gmsh.finalize()
        # Récupération des abscisses et ordonnées (dans l'ordre des noeuds)
        L = []
        self.x = np.zeros(np.max(self.Noeuds))
        self.y = np.zeros(np.max(self.Noeuds))
        for i in range(len(self.Noeuds)):
            if self.Noeuds[i] not in L:
                self.x[int(self.Noeuds[i]-1)] = self.Coord[int(3*i)]
                self.y[int(self.Noeuds[i]-1)] = self.Coord[int(3*i+1)]
                L=L+[self.Noeuds[i]]
    def getNoeuds(self):
        return self.Noeuds
    def getCoord(self):
        return self.Coord

class Triangles(Mesh):
    def __init__(self,Maill):
        """
        Description
        ----------
        Cette classe permet de récupérer les informations des triangles du maillage.

        Parameters
        ----------
        Maill : Class
            Objet de classe Maillage.
            
        Returns
        -------
        None.
        """
        self.Tri = []
        self.Nt = int(np.size(Maill.Noeuds)/3)
        self.Nn = int(np.max(Maill.Noeuds))
        self.NnWOb = np.size(Maill.NoeudsNotBoundary)
        for p in range(self.Nt):
            j = 9*p
            k = 3*p
            TriInfo = [([Maill.Noeuds[k],Maill.Coord[j:j+3]],[Maill.Noeuds[k+1],Maill.Coord[j+3:j+6]],[Maill.Noeuds[k+2],Maill.Coord[j+6:j+9]])]
            self.Tri = self.Tri+TriInfo
        for i in range(self.Nt):
            for j in range(3):
                if self.Tri[i][j][0] in Maill.NoeudsNotBoundary:
                    self.Tri[i][j].append("Not boundary")
                else:
                    self.Tri[i][j].append("Boundary")
    def PreCalcul(self):
        """
        Description
        -------
        Précalcul de différentes données du maillage pour l'assemblage des matrices de masse et de rigidité.

        Returns
        -------
        PC : Liste
            Liste de Tuple contenant différents calculs pour chaque triangle.

        """
        PC = []
        for p in range(self.Nt):
            T = self.Tri[p]
            S1 = T[0]
            S2 = T[1]
            S3 = T[2]
            S1S3 = norm(S3[1]-S1[1],2)**2
            S2S1 = norm(S1[1]-S2[1],2)**2
            S1S3psS2S1 = np.dot(S3[1]-S1[1],S1[1]-S2[1])
            Aire = 0.5*norm(np.cross(S3[1]-S1[1],S1[1]-S2[1]),2)
            PC = PC+[(S1S3,S2S1,S1S3psS2S1,Aire)]
        return PC