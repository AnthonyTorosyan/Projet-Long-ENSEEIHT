
import numpy as np

class Source:
    def Crop(self,SourceMatrix,Triangles):
        """
        Description
        ----------
        Cette fonction permet d'enlever les bords dans le vecteur Source

        Parameters
        ----------
        SourceMatrix : array([NnWOb,Ntemps])
            Matrice contenant toutes les valeurs de la source.
        Triangles : Class
            Classe contenant les informations sur les triangles du maillage.

        Returns
        -------
        array([Nn-NnWOb,Ntemps])
            Matrice des valeurs de la source sans les bords.
        """
        return SourceMatrix[Triangles.Nn-Triangles.NnWOb:Triangles.Nn,:] 
        
class constante(Source):
    def __init__(self,Amp,Maill,Ntemps):
        """
        Description
        ----------
        Permet d'obtenir une source constante.

        Parameters
        ----------
        Amp : float
            Amplitude de la source.
        Maill : Class
            Objet de classe Maillage.
        Ntemps : int
            Nombre de points dans la discrétisation en temps.

        Returns
        -------
        None.
        """
        self.NameSource = "Constante"
        self.val = Amp*np.ones([Maill.Nn,Ntemps])
    def getval(self):
        return self.val 
       
# class sinusoidale(Source):
#     def __init__(self,Amp,f0, Maill,Tfin,Ntemps):
#         """
#         Description
#         ----------
#         Permet d'obtenir une source sinusoidale.

#         Parameters
#         ----------
#         Amp : float
#             Amplitude de la source.
#         Maill : Class
#             Objet de classe Maillage.
#         Ntemps : int
#             Nombre de points dans la discrétisation en temps.
#         Tfin : float
#                 Temps final.

#         Returns
#         -------
#         None.
#         """
#         t = [i for i in range(Ntemps)]
#         t = Tfin/(Ntemps-1)*np.array(t)
#         It = Amp*np.sin(2*np.pi*f0*t)+1
#         source = np.array([It for i in range(Maill.Nn)])
#         self.val = source
    
#     def getval(self):
#         return self.val 

# class sinusoidale_w(Source):
#     def __init__(self, Amp, f0, Maill, w_sweep):
#         I_w= (1/(2*np.pi*f0))*(1/(1-(w_sweep/(2*np.pi*f0))**2))
#         # source = np.array([I_w for i in range(Maill.Nn)])
#         source = I_w
#         self.source=source
#     def getval(self):
#         return self.source

# class sinusoidale_scalaire(Source):
#     def __init__(self, Amp, f0, w):
#         source= (1/(2*np.pi*f0))*(1/(1-(w/(2*np.pi*f0))**2))
#         self.source=source
#     def getval(self):
#         return self.source
    
class diffusion1(Source):
    def __init__(self,Maill,Tfin,Ntemps):
        """
        Description
        ----------
        Calcul de la source 1+2*x*t.

        Parameters
        ----------
        Maill : Class
            Objet de classe Maillage.
        Tfin : float
            Temps final.
        Ntemps : int
            Nombre de points dans la discrétisation en temps.

        Returns
        -------
        None.
        """
        self.NameSource = "Diffusion1"
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        self.val = 1.0+2*np.tensordot(X,t,axes=0)
    def getval(self):
        return self.val
                
# class diffusion2(Source):
#     def __init__(self,Maill,Tf,Npas):
#         n=max(Maill.Noeuds)
#         s=np.zeros((n,Npas))
#         for j in range(Npas):
#             t=j*Tf/(Npas-1)
#             L=[]
#             for i in range (len(Maill.Noeuds)):
#                 if Maill.Noeuds[i] not in L:
#                     x=Maill.Coord[int(3*i)]
#                     y=Maill.Coord[int(3*i+1)]
#                     ut=np.sin(np.pi*x)*np.sin(np.pi*y)-1/2*np.sin(np.pi*x)*np.sin(2*np.pi*y)+np.pi/2*np.sin(2*np.pi*x)*np.sin(np.pi*y)*np.cos(np.pi*t)+2*np.pi/3*np.sin(2*np.pi*x)*np.sin(2*np.pi*y)*np.cos(2*np.pi*t)+4*np.pi/5*np.sin(4*np.pi*x)*np.sin(4*np.pi*y)*np.cos(4*np.pi*t)
#                     us=-2*np.pi**2*np.sin(np.pi*x)*np.sin(np.pi*y)*t-5/4*np.pi**2*np.sin(np.pi*x)*np.sin(2*np.pi*y)*(1-t)-3/4*np.pi**2*np.sin(2*np.pi*x)*np.sin(np.pi*y)*np.sin(np.pi*t)-8/3*np.pi**2*np.sin(2*np.pi*x)*np.sin(2*np.pi*y)*np.sin(2*np.pi*t)-32/5*np.pi**2*np.sin(4*np.pi*x)*np.sin(4*np.pi*y)*np.sin(4*np.pi*t)
#                     s[int(Maill.Noeuds[i]-1),j]=ut-us
#                     print("s",s[int(Maill.Noeuds[i]-1),j])
#                     L=L+[Maill.Noeuds[i]]
#         self.val=s
class diffusion2(Source):
    def __init__(self,Maill,Tfin,Ntemps,C1,C2):
        """
        Description
        ----------
        Calcul de la source pi*sin(pi/L*(x-L))*sin(pi/L*(y-L))*(C1*cos(pi*t)+2*C2*pi/L*sin(pi*t))

        Parameters
        ----------
        Maill : Class
            Onjet de classe Maillage.
        Tfin : float
            Temps final.
        Ntemps : int
            Nombre de points dans la discrétisation en temps.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        None.
        """
        self.NameSource = "Diffusion2"
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        Y = Maill.y
        L = np.max(Maill.Coord)
        self.val = np.pi*np.tensordot(np.sin(2*np.pi/L*(X-L))*np.sin(2*np.pi/L*(Y-L)),C1*np.cos(np.pi*t)+8*C2*np.pi/L/L*np.sin(np.pi*t),axes=0)
 
class diffusion3(Source):
    def __init__(self,M,Maill,Tfin,Ntemps,C1,C2):
        """
        Description
        ----------
        Calcul de la source liée à la solution analytique Diffusion3. Cela crée
        une source contenant un nombre de modes fixé par l'utilisateur.

        Parameters
        ----------
        M : int
            Nombre de modes pour la source Diffusion3.
        Maill : Class
            Objet de classe Maillage.
        Tfin : float
            Temps final.
        Ntemps : int
            Nombre de points dans la discrétisation temporelle.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        None.

        """
        self.NameSource = "Diffusion3"
        Nn = int(np.max(Maill.Noeuds))
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        Y = Maill.y
        self.val = np.zeros([Nn,Ntemps])
        for m in range(M):
            dt = np.tensordot(np.sin(2*np.pi*(X-1))*np.sin(2*np.pi*(Y-1))*np.cos(2*np.pi*m/M*X)*np.cos(2*np.pi*m/M*Y),np.pi*np.cos(np.pi*t)*np.cos(2*np.pi*m/M*t)-2*np.pi*m/M*np.sin(np.pi*t)*np.sin(2*np.pi*m/M*t),axes=0)
            dx1 = np.tensordot(np.sin(2*np.pi*(Y-1))*np.cos(2*np.pi*m/M*Y)*(-4*np.pi**2*(np.sin(2*np.pi*(X-1))*np.cos(2*np.pi*m/M*X)+m/M*np.sin(2*np.pi*m/M*X)*np.cos(2*np.pi*(X-1)))),np.sin(np.pi*t)*np.cos(2*np.pi*m/M*t),axes=0)
            dy1 = np.tensordot(np.sin(2*np.pi*(X-1))*np.cos(2*np.pi*m/M*X)*(-4*np.pi**2*(np.sin(2*np.pi*(Y-1))*np.cos(2*np.pi*m/M*Y)+m/M*np.sin(2*np.pi*m/M*Y)*np.cos(2*np.pi*(Y-1)))),np.sin(np.pi*t)*np.cos(2*np.pi*m/M*t),axes=0)
            dx2 = np.tensordot(np.sin(2*np.pi*(Y-1))*np.cos(2*np.pi*m/M*Y)*(-4*m/M*np.pi**2*(m/M*np.cos(2*np.pi*m/M*X)*np.sin(2*np.pi*(X-1))+np.cos(2*np.pi*(X-1))*np.sin(2*np.pi*m/M*X))),np.sin(np.pi*t)*np.cos(2*np.pi*m/M*t),axes=0)
            dy2 = np.tensordot(np.sin(2*np.pi*(X-1))*np.cos(2*np.pi*m/M*X)*(-4*m/M*np.pi**2*(m/M*np.cos(2*np.pi*m/M*Y)*np.sin(2*np.pi*(Y-1))+np.cos(2*np.pi*(Y-1))*np.sin(2*np.pi*m/M*Y))),np.sin(np.pi*t)*np.cos(2*np.pi*m/M*t),axes=0)
            self.val = self.val+C1*dt-C2*(dx1+dx2+dy1+dy2)

# class diffusion3(Source):
#     def __init__(self,Maill,Tfin,Ntemps,C1,C2):
#         """
#         Description
#         ----------
#         Calcul de la source pi*sin(pi/L*(x-L))*sin(pi/L*(y-L))*(C1*cos(pi*t)+2*C2*pi/L*sin(pi*t))

#         Parameters
#         ----------
#         Maill : Class
#             Onjet de classe Maillage.
#         Tfin : float
#             Temps final.
#         Ntemps : int
#             Nombre de points dans la discrétisation en temps.
#         C1 : float
#             Coefficient de l'EDP devant la dérivée temporelle.
#         C2 : float
#             Coefficient de l'EDP devant l'opérateur spatial.

#         Returns
#         -------
#         None.
#         """
#         t = [i for i in range(Ntemps)]
#         t = Tfin/(Ntemps-1)*np.array(t)
#         X = Maill.x
#         Y = Maill.y
#         L = np.max(Maill.Coord)
#         self.val = np.pi*np.tensordot(np.sin(2*np.pi/L*(X-L))*np.sin(2*np.pi/L*(Y-L)),C1*np.cos(np.pi*t)+8*C2*np.pi/L/L*np.sin(np.pi*t),axes=0)