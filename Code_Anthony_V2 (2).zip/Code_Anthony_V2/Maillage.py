# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 12:52:58 2023

@author: antho
"""

import numpy as np
import gmsh
from numpy.linalg import norm

class Mesh:
    def __init__(self,NomFichier):
        self.NomFichier = NomFichier
        # Initialiser GMSH
        gmsh.initialize()
        # Charger un fichier .msh
        gmsh.open(NomFichier)
        # Récupérer les noeuds et coordonnées pour chaque triangle
        GetAll = gmsh.model.mesh.getNodesByElementType(2)
        self.Noeuds = GetAll[0]
        self.Coord = GetAll[1]
        # Finaliser GMSH
        gmsh.finalize()

class Triangles(Mesh):
    def __init__(self,Noeuds,Coord):
        self.Nt = int(np.size(Noeuds)/3)
        self.Tri = []
        for p in range(self.Nt):
            j = 9*p
            k = 3*p
            TriInfo = [([Noeuds[k],Coord[j:j+3]],[Noeuds[k+1],Coord[j+3:j+6]],[Noeuds[k+2],Coord[j+6:j+9]])]
            self.Tri = self.Tri+TriInfo
    def PreCalcul(self):
        PC = []
        for p in range(self.Nt):
            T = self.Tri[p]
            S1 = T[0]
            S2 = T[1]
            S3 = T[2]
            S1S3 = norm(S3[1]-S1[1],2)**2
            S2S1 = norm(S1[1]-S2[1],2)**2
            S1S3psS2S1 = np.dot(S3[1]-S1[1],S1[1]-S2[1])
            Aire = 0.5*norm(np.cross(S3[1]-S1[1],S1[1]-S2[1]),2)
            PC = PC+[(S1S3,S2S1,S1S3psS2S1,Aire)]
        return PC
        
#### TEST #####
# Maillage = Mesh("MySquare.msh")