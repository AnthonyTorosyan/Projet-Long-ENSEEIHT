# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 11:11:50 2023

@author: antho
"""

from scipy.sparse import coo_matrix
import numpy as np
from numpy.linalg import norm

class Triplet:
    def __init__(self):
        self.data = ([],([],[]))
    def __str__(self):
        return str(self.data)
    def append(self,I,J,val):
        # Ajoutes le triplet [I,J,val] dans self.data
        # COMMENTAIRE A FAIRE
        #self.data = (val,(I,J))
        self.data[0].append(val)
        self.data[1][0].append(I)
        self.data[1][1].append(J)
        
class Assemblage:
    def __init__(self,C1,C2):
        # paramètres de l'EDP
        self.C1 = C1
        self.C2 = C2
    def FaireAssemblage(self,Triangles,PreCalcul):
        # Récupération des informations du maillage
        Triangle = Triangles.Tri
        Nt = Triangles.Nt
        # Instanciation d'un Triplet
        t = Triplet()
        for p in range(Nt):
            T = Triangle[p]
            PC = PreCalcul[p]
            # Matrice de rigidité K
            K22 = PC[0]/4/PC[3]
            K33 = PC[1]/4/PC[3]
            K23 = PC[2]/4/PC[3]
            K = np.array([[K22+K33+K23,-K23-K22,-K23-K33],[-K23-K22,K22,K23],[-K23-K33,K23,K33]])
            # Matrice de masse M
            M = PC[3]/12*np.array([[2,1,1],[1,2,1],[1,1,2]])
            # Matrice élémentaire totale
            A = self.C1*K+self.C2*M
            for i in range(3):
                #I = loc2glob(T,p,i)
                I = int(T[i][0]-1)
                #I = T[p,i,0]
                for j in range(3):
                    #J = loc2glob(T,p,j)
                    #J = T[p,j,0]
                    J = int(T[j][0]-1)
                    t.append(I,J,A[i,j])
        return coo_matrix(t.data)
        # A voir pour le format csr
        
##### Test #####

# t = Triplet()
# val = [1.1,2,1,2.3,0.5,2,2,1]
# I = [0,0,1,2,3,3,3,0]
# J = [0,3,1,2,0,1,3,0]
# for i in range(len(val)):
#     t.append(I[i],J[i],val[i])
# A = coo_matrix(t.data)
# A = A.tocsr()
# print(A.toarray())
