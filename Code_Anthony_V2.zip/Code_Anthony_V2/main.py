# -*- coding: utf-8 -*-
"""
Created on Wed Feb  8 20:57:14 2023

@author: antho
"""

from Assemblage import *
from Maillage import *

# Définition du maillage
Maill = Mesh("MySquare.msh")
Tri = Triangles(Maill.Noeuds,Maill.Coord)
PC = Tri.PreCalcul()
# Définition de l'assemblage 
Ass = Assemblage(1,0)
A = Ass.FaireAssemblage(Tri,PC)

print(A.toarray())