# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 13:33:40 2023

@author: arabej
"""
import gmsh
import sys

# Initialiser GMSH
gmsh.initialize(sys.argv)
# Demander à GMSH d'afficher des informations dans le terminal
gmsh.option.setNumber("General.Terminal", 1)

# Créer un modèle et le nommer "MySquare"
model = gmsh.model
model.add("MySquare")

# Paramètres
L = 1 # Taille du côté
h = 0.1 # Taille de maillage

# Créer 4 points pour les coins du carré
points = []
points.append(model.geo.addPoint(0, 0, 0, h))
points.append(model.geo.addPoint(L, 0, 0, h))
points.append(model.geo.addPoint(L, L, 0, h))
points.append(model.geo.addPoint(0, L , 0, h))

# Créer 4 lignes pour les côtés du carré
lines = []
for j in range(4):
  lines.append(model.geo.addLine(points[j],points[(j+1)%4]))

# Boucle de courbe et surface
curveloop = model.geo.addCurveLoop(lines)
square = model.geo.addPlaneSurface([curveloop])

# Groupes physiques
# model.addPhysicalGroup(1, lines, 1)
# model.addPhysicalGroup(2, [square], 1)

# Cette commande est obligatoire et synchronise CAD avec le modèle GMSH. Plus vous la lancez, moins c'est bon pour les performances.
model.geo.synchronize()
# Maillage (2D)
model.mesh.generate(2)
# Écrire sur le disque
gmsh.write("MySquare.msh")
# Lancer l'interface graphique (pas obligatoire du tout)
gmsh.fltk.run();
# Finaliser GMSH
gmsh.finalize()

