# -*- coding: utf-8 -*-
"""
Created on Thu Feb 16 19:05:47 2023

@author: antho
"""

from Utile import Coefficient, Triplet
import numpy as np
from numpy.linalg import norm
from scipy.sparse.linalg import spsolve,svds
from scipy.sparse import coo_matrix
from time import process_time

class PGD:
    def __init__(self,NnWOb,Tfin,Ntemps,Mode,MaxIter,Tol):
        """
        Description
        ----------
        Classe permettant d'utiliser la méthode Proper Generalized Decomposition.
        
        Parameters
        ----------
        NnWOb : int
            Nombre de noeuds à l'intérieur du maillage.
        Tfin : float
            Temps final du calcul.
        Ntemps : int
            Nombre de points en temps.
        Mode : int
            Nombre de modes à calculer.
        MaxIter : int
            Maximum d'itérations pour la recherche des modes.
        Tol : float
            Tolérance pour la convergence des modes.

        Returns
        -------
        None.
        """
        self.NnWOb = NnWOb
        self.Tfin = Tfin
        self.Ntemps = Ntemps
        self.dt = self.Tfin/float(self.Ntemps-1)
        self.Mode = Mode
        self.MaxIter = MaxIter
        self.Tol = Tol
        self.Coeff = Coefficient(self.Ntemps,self.dt,self.NnWOb,self.Mode)
        self.Stot = np.zeros([self.Ntemps,self.Mode])
        self.Rtot = np.zeros([self.NnWOb,self.Mode])
        self.TpsCalcul = 0
    def CalculSm(self,R,Source,K,M,C1,C2):
        """
        Description
        ----------
        Calcul de S_m(t) à l'itération Iter.

        Parameters
        ----------
        R : array(NnWOb)
            R_m(x) à l'itération Iter.
        Source : array([NnWOb,Ntemps])
            Source de l'EDP.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        S : array(Ntemps)
            S_m(t) à l'itération Iter.
        """
        # Calcul des coefficients
        AR = C2*R@K@R
        BR = C1*R@M@R
        # Calcul du second membre
        CS = self.Coeff.CS(Source,R,self.Stot,self.Rtot,M,K,C1,C2)
        # Schéma d'Euler implicite
        S = self.Coeff.EulerImplicite(CS,AR,BR,self.dt,self.Ntemps)
        # Quelques affichages
        print("AR",AR)
        print("BR",BR)
        print("CS",norm(CS,2))
        print("norme S",norm(S,2),end="\n \n") 
        return S
    def CalculRm(self,S,Source,K,M,C1,C2):
        """
        Description
        ----------
        Calcul de R_m(x) à l'itération Iter.

        Parameters
        ----------
        S : array(Ntemps)
            S_m(t) à l'itération Iter-1.
        Source : array([NnWOb,Ntemps])
            Source de l'EDP.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        R : array(NnWOb)
            R_m(x) à l'itération Iter.
        """
        # Calcul des coefficients
        AS = self.Coeff.MethodeTrapeze(S**2,self.dt,self.Ntemps)
        BS = self.Coeff.MethodeTrapeze(np.gradient(S)*S,self.dt,self.Ntemps)
        # Calcul du second membre
        CR = self.Coeff.CR(Source,S,self.Stot,self.Rtot,M,K,C1,C2)
        # Résolution du système linéaire
        R = spsolve(C2*AS*K+C1*BS*M,CR)
        # Quelques affichages
        print("AS",AS)
        print("BS",BS)
        print("CR",norm(CR,2))
        print("norme R",norm(R,2),end="\n \n")
        return R
    def Calcul(self,Source,K,M,C1,C2):
        """
        Description
        ----------
        Algorithme de la méthode PGD

        Parameters
        ----------
        Source : array([NnWOb,Ntemps])
            Source de l'EDP.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        None.
        """
        ti = process_time()
        for m in range(self.Mode):
            S = np.ones(self.Ntemps)
            R = np.zeros(self.NnWOb)
            Stop = False
            Iter = 0
            while (Stop == False) and (Iter <= self.MaxIter):
                Iter = Iter+1
                Rbefore = R
                Sbefore = S
                # Calcul du mode m de l'itération Iter-1 (pour le critère d'arrêt)
                M_mbefore = np.tensordot(Rbefore,Sbefore,axes=0)
                # Calcul de R_m à l'itération Iter
                R = PGD.CalculRm(self,S,Source,K,M,C1,C2)
                # Calcul de S_m à l'itération Iter
                S = PGD.CalculSm(self,R,Source,K,M,C1,C2)
                # Calcul du mode m de l'itération Iter (pour le critère d'arrêt)
                M_m = np.tensordot(R,S,axes=0)
                # Calcul de la norme du résidu pour la convergence
                NormeResidu = norm(M_m-M_mbefore,'fro')/(1+norm(M_mbefore,'fro'))
                Stop = NormeResidu <= self.Tol
                # Quelques affichages
                print("Itération",Iter)
                print("Norme Résidu",NormeResidu)
                print("Stop",Stop,end="\n \n")
            # Enregistrement du mode
            self.Stot[:,m] = S 
            self.Rtot[:,m] = R
        self.TpsCalcul = process_time()-ti

class POD:
    def __init__(self,NnWOb,Tfin,Ntemps,Snaps,Tol_proj):
        """
        Description
        ----------
        Classe permettant d'utiliser la méthode Proper ORTHOGONAL Decomposition.
        
        Parameters
        ----------
        NnWOb : int
            Nombre de noeuds à l'intérieur du maillage.
        Tfin : float
            Temps final du calcul.
        Ntemps : int
            Nombre de points en temps.
        Mode : int
            Nombre de modes à calculer.
        Snaps : int
            Le nombre de pas de temps pris en compte (snapshot) pour le calcul 
            de la solution non réduite As.
        Tol_proj : float
            Tolérance pour la prise en compte des valeurs singulières de la SVD.

        Returns
        -------
        None.
        """
        self.NnWOb = NnWOb
        self.Tfin = Tfin
        self.Ntemps = Ntemps
        self.dt = self.Tfin/float(self.Ntemps-1)
        self.Snapshot = Snaps
        self.Tol_proj = Tol_proj
    def snapshot(self,K,M,F,a0,m,pas):
        """
        Description
        ----------
        Réslution du système pour les m premiers pas de temps (Snapshots) 
        
        K.Ad + M. dAd/dt = F
        
        Parameters
        ----------
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        F : array([NnWOb,Ntemps])
            Matrice telle que ces chaque colonne correspond au second membre du
            système pour un instant donné ( t(i)=i.pas pour i=0 à Ntemps-1 ).
        a0 : array([NnWOb])
            Condition initiale du schéma d'Euler.
        m : int
            le nombre de Snapshot.
        pas : float
            le pas du schéma d'Euler. pas= Tfin/(Ntemps-1)

        Returns
        -------
        As : array([NnWOb,m])
            Matrice contenant les résultats de la résolution des m premiers pas 
            de temps.

        """
        As=np.zeros((self.NnWOb,m))
        As.T[0]=a0
        #P, L, U=sp.linalg.lu(N)
        #Ninv=np.linalg.inv(N)      
        for i in range (m-1):
            #sec_membre=F.T[i]-np.dot(K,As.T[i])
            sec_membre=F.T[i]-K@As.T[i]
            #dAdt=np.linalg.solve(M,sec_membre)
            dAdt=spsolve(M,sec_membre.T)
            #As.T[i+1]=As.T[i]+pas*np.dot(Ninv,F.T[i]-np.dot(M,As.T[i]))
            #scipy.linalg.solve
            As.T[i+1]=As.T[i]+pas*dAdt
        return coo_matrix(As)        
    def oper_proj(self,As):
        """
        Description
        -----------
        Calcul de l'opérateur de projection P à partir des résultats des snapshots.
    
        Parameters
        ----------
        As : array([NnWOb,m])
            Matrice contenant les résultats de la résolution des m premiers pas 
            de temps.

        Returns
        -------
        P : array([NnWOb,r]) avec r est la taille réduite du problème

        """
        #u,s,v=np.linalg.svd(As)
        u,s,v = np.linalg.svd(As.toarray())
        sfiltr=np.zeros(len(s))
        j=0
        for i in range(len(s)):
            if s[i]>self.Tol_proj:
                sfiltr[j]=s[i]
                j=j+1
        sigma=np.zeros(j)
        for i in range(j):
            sigma[i]=sfiltr[i]        
        P=np.zeros((As.shape[0],j))
        # for i in range (len(s)):
        #     sigma[i][i]=s[i]
        #P=np.dot(u,sigma)
        print(sigma)
        for i in range (j):
            P.T[i]=s[i]*u.T[i]
        return coo_matrix(P)
    def reduc(K,M,F,P):
        """
        Description
        -----------
        Réduction des données du problème pour construire le système réduit 
        à résoudre

        Parameters
        ----------
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        F : array([NnWOb,Ntemps])
            Matrice telle que ces chaque colonne correspond au second membre du
            système pour un instant donné ( t(i)=i.pas pour i=0 à Ntemps-1 ).
        P : array([NnWOb,r]) 
            avec r est la taille réduite du problème

        Returns
        -------
        Kr : array([r,r])
            Matrice de rigidité.
        Mr : array([r,r])
            Matrice de masse.
        Fr : array([r,Ntemps])
            Matrice telle que ces chaque colonne correspond au second membre du
            système pour un instant donné ( t(i)=i.pas pour i=0 à Ntemps-1 ).

        """
        Kr=P.T@K@P
        Mr=P.T@M@P
        Fr=P.T@F
        return (Kr,Mr,Fr)    
    def solve_reduc(self,Mr,Nr,Fr,ar0,Tf,pas,P):
        """
        Description
        -----------
        Résolution du système réduit avec la méthode d'Euler et le calcul de 
        la solution du problème initial

        Parameters
        ----------
        Kr : array([r,r])
            Matrice de rigidité.
        Mr : array([r,r])
            Matrice de masse.
        Fr : array([r,Ntemps])
            Matrice telle que ces chaque colonne correspond au second membre du
            système pour un instant donné ( t(i)=i.pas pour i=0 à Ntemps-1 ).
        ar0 : array([r])
            Condition initiale du problème réduit, elle est exprimée en fonction
            de la condition initiale du problème initial tel que: 
                ar0 = transpose(P).a0 
        T : int
            Temps final.
        pas : float
            le pas du schéma d'Euler. pas= Tfin/(Ntemps-1)
        P : array([NnWOb,r]) 
            avec r est la taille réduite du problème

        Returns
        -------
        Ad : array([NnWOb,Ntemsp])
            Solution du Problème initial.

        """
        Ar=np.zeros((Mr.shape[0],self.Ntemps))
        print(Mr.shape)
        Ar.T[0]=ar0
        
        #P, L, U=sp.linalg.lu(N)
        #Ninv=np.linalg.inv(Nr)      
        for i in range (self.Ntemps-1):
            sec_membre=Fr.T[i]-Mr@Ar.T[i]
            dAdt=spsolve(Nr,sec_membre.T)
            #Ar.T[i+1]=Ar.T[i]+pas*np.dot(Ninv,Fr.T[i]-np.dot(Mr,Ar.T[i]))
            Ar.T[i+1]=Ar.T[i]+pas*dAdt
        Ad=P@Ar    
        #print(np.shape(Ar))
        return Ad
    def sec_membre(self,Triangles,PreCalcul,source):
        """
        Description
        -----------
        Calcul du second membre tel que les conditions aux limites sont nulles

        Parameters
        ----------
        Triangles : Type Triangles
            Cette classe permet de récupérer les informations des triangles du maillage..
        PreCalcul : Liste
            Liste de Tuple contenant différents calculs pour chaque triangle.
        source : array([Nn,Ntemps])
            Matrice contenant les valeurs de la source pour chaque noeuds pour
            chaque pas de temps.

        Returns
        -------
        SM : array([NnWOb,Ntemps])
            Second membre du problème pour chaque pas de temps.

        """
        # Récupération des informations du maillage
        Tri = Triangles.Tri
        Nt = Triangles.Nt
        Nn = Triangles.Nn
        NnWOb = Triangles.NnWOb
        # Instanciation d'un Triplet
        t = Triplet()
        for p in range(Nt):
            T = Tri[p]
            PC = PreCalcul[p]                 
            # Matrice de masse M
            M = PC[3]/12*np.array([[2,1,1],[1,2,1],[1,1,2]])
            # Second membre élémentaire
            for j in range(np.shape(source)[1]):
                F=np.array([source[int(T[0][0]-1),j],source[int(T[1][0]-1),j],source[int(T[2][0]-1),j]])   
                SM=np.dot(M,F)
                for i in range(3):
                    I = int(T[i][0]-1)
                    if T[i][2] == "Not boundary":
                        t.append(I,j,SM[i])
        SM = coo_matrix(t.data)
        CropR = Triplet()
        j = 0
        for i in range(Nn-NnWOb,Nn):
            CropR.append(i,j,1)
            j = j+1
        CropRight = coo_matrix(CropR.data)
        SM = np.transpose(CropRight)@SM                   
        return SM
    def sec_membre2(M,source):
        return M@source
    def calcul(self,Triangles,PreCalcul,source,K,M,a0,m):
        """
        Description
        -----------
        Procédure de la méthode POD

        Parameters
        ----------
        Triangles : Type Triangles
            Cette classe permet de récupérer les informations des triangles du maillage..
        PreCalcul : Liste
            Liste de Tuple contenant différents calculs pour chaque triangle.
        source : array([Nn,Ntemps])
            Matrice contenant les valeurs de la source pour chaque noeuds pour
            chaque pas de temps.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        a0 : array([NnWOb])
            Condition initiale du schéma d'Euler.
        m : int
            le nombre de Snapshot.

        Returns
        -------
        T : array([Nn,Ntemps])
            Solution du problème: une matrice qui contient les valeurs de la
            solution pour chaque noeuds pour chaque pas de temps.

        """
        ti=process_time()
        #SM = POD.sec_membre(self, Triangles, PreCalcul, source)
        SM = POD.sec_membre2(M, source)
        #F = SM.toarray()
        F = SM
        As=POD.snapshot(self,K, M, F, a0, m, self.dt)
        P=POD.oper_proj(self,As)
        #print(P.shape)
        (Kr,Mr,Fr)=POD.reduc(K, M, F, P)
        ar0=P.T@a0
        print("P",P.shape)
        Ad=POD.solve_reduc(self,Kr, Mr, Fr, ar0, self.Tfin, self.dt, P)
        T = np.zeros([Triangles.Nn,self.Ntemps])
        for i in range(self.Ntemps):
            T[Triangles.Nn-Triangles.NnWOb:Triangles.Nn,i] = Ad[:,i]
        print("t_calcul",process_time()-ti)
        return T    