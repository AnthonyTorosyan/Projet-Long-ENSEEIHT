# -*- coding: utf-8 -*-
"""
Created on Thu Feb  9 17:39:56 2023

@author: antho
"""

from Utile import Triplet
import numpy as np
from numpy.linalg import norm
from scipy.sparse.linalg import spsolve
from scipy.sparse import coo_matrix

class Resolution:
    def __init__(self):
        self.Methode = ""
    def getMethode(self):
        return self.Methode
    def Methode(self,Meth):
        self.Methode = Meth
        
class PGD(Resolution):
    def __init__(self,Triangles,Tfin,Ntemps,Mode,Rtol,Stol):
        self.Tfin = Tfin
        self.Ntemps = Ntemps
        self.dt = self.Tfin/float(self.Ntemps)
        self.Mode = Mode
        self.Rtol = Rtol
        self.Stol = Stol
        self.Stot = np.zeros([self.Ntemps,self.Mode])
        self.Rtot = np.zeros([Triangles.Nn,self.Mode])
    def CalculSn(self,Triangles,R,Source,PreCalcul,C1,C2):
        # Calcul des coefficients
        Int = 0
        for p in range(Triangles.Nt):
            T = Triangles.Tri[p]
            PC = PreCalcul[p]
            # Matrice de rigidité élémentaire
            K22 = PC[0]/4/PC[3]
            K33 = PC[1]/4/PC[3]
            K23 = PC[2]/4/PC[3]
            Kelm = np.array([[K22+K33+2*K23,-K23-K22,-K23-K33],[-K23-K22,K22,K23],[-K23-K33,K23,K33]])
            #Int = Int+1/4/PC[3]*(R[int(T[0][0]-1)]**2*(PC[0]+PC[1]+2*PC[2])+R[int(T[1][0]-1)]**2*PC[0]+R[int(T[2][0]-1)]**2*PC[1])
            Relm = np.array([R[]])
            Int = Int+
        AR = C2*Int
        Int = 0
        for p in range(Triangles.Nt):
            T = Triangles.Tri[p]
            PC = PreCalcul[p]
            Int = Int+PC[3]/6*(R[int(T[0][0]-1)]**2+R[int(T[1][0]-1)]**2+R[int(T[2][0]-1)]**2)
        BR = C1*Int
        Int = 0
        for p in range(Triangles.Nt):
            T = Triangles.Tri[p]
            PC = PreCalcul[p]
            Int = Int+PC[3]/3*(R[int(T[0][0]-1)]+R[int(T[1][0]-1)]+R[int(T[2][0]-1)])
        CS1 = Int
        VectInt = np.zeros(self.Mode)
        for i in range(self.Mode):
            Int = 0
            Rmode = self.Rtot[:,i]
            for p in range(Triangles.Nt):
                T = Triangles.Tri[p]
                PC = PreCalcul[p]
                Int = Int+PC[3]/6*(Rmode[int(T[0][0]-1)]*R[int(T[0][0]-1)]+Rmode[int(T[1][0]-1)]*R[int(T[1][0]-1)]+Rmode[int(T[2][0]-1)]*R[int(T[2][0]-1)])
            VectInt[i] = Int
        CS2interm = (self.Stot[1:self.Ntemps,:]-self.Stot[:self.Ntemps-1,:])/self.dt
        CS2 = CS2interm@VectInt
        VectInt = np.zeros(self.Mode)
        for i in range(self.Mode):
            Int = 0
            Rmode = self.Rtot[:,i]
            for p in range(Triangles.Nt):
                T = Triangles.Tri[p]
                PC = PreCalcul[p]
                Int = Int+1/4/PC[3]*(R[int(T[0][0]-1)]*Rmode[int(T[0][0]-1)]*(PC[0]+PC[1]+2*PC[2])+R[int(T[1][0]-1)]*Rmode[int(T[1][0]-1)]*PC[0]+R[int(T[2][0]-1)]*Rmode[int(T[2][0]-1)]*PC[1])
            VectInt[i] = Int
        CS3 = C2*self.Stot[:self.Ntemps-1,:]@VectInt
        CS = CS1-CS2-CS3
        # Schéma d'Euler
        S = np.zeros(self.Ntemps)
        for i in range(self.Ntemps-1):
            S[i+1] = S[i]+self.dt/BR*(CS[i]-AR*S[i])
        return S
    def CalculRn(self,Triangles,S,Source,PreCalcul,K,M,C1,C2):
        # Calcul des coefficients
        AS = np.sum((S[1:self.Ntemps]-S[:self.Ntemps-1])*S[1:self.Ntemps])
        BS = np.sum(S[:self.Ntemps-1]**2*self.dt)
        CR1 = Source*np.sum(S[:self.Ntemps]*self.dt)
        CR2interm = np.transpose(self.Stot[1:self.Ntemps,:]-self.Stot[:self.Ntemps-1,:])@S[1:self.Ntemps]
        # Intégrale des R sur le domaine
        # VectInt = np.zeros(self.Mode)
        # for i in range(self.Mode):
        #     Int = 0
        #     Rmode = self.Rtot[:,i]
        #     for p in range(Triangles.Nt):
        #         T = Triangles.Tri[p]
        #         PC = PreCalcul[p]
        #         Int = Int+PC[3]/3*(Rmode[int(T[0][0]-1)]+Rmode[int(T[1][0]-1)]+Rmode[int(T[2][0]-1)])
        #     VectInt[i] = Int
        # CR2 = VectInt@CR2interm
        CR2 = self.Rtot@CR2interm
        CR = CR1-CR2
        # Assemblage du second membre
        t = Triplet()
        for p in range(Triangles.Nt):
            T = Triangles.Tri[p]
            PC = PreCalcul[p]
            # Matrice de masse M élémentaire
            Melm = PC[3]/12*np.array([[2,1,1],[1,2,1],[1,1,2]])
            F = np.array([CR[int(T[0][0]-1)],CR[int(T[1][0]-1)],CR[int(T[2][0]-1)]])
            F = Melm@F
            for i in range(3):
                I = int(T[i][0]-1)
                t.append(I,0,F[i])
        SM = coo_matrix(t.data)
        return spsolve(C2*AS*K+BS*M,SM)
    def Calcul(self,Triangles,Source,PreCalcul,K,M,C1,C2):
        for i in range(self.Mode):
            S = np.ones(self.Ntemps)
            R = np.ones(Triangles.Nn)
            Stop = False
            while Stop == False:
                Rbefore = R
                Sbefore = S
                R = PGD.CalculRn(self,Triangles,S,Source,PreCalcul,K,M,C1,C2)
                S = PGD.CalculSn(self,Triangles,R,Source,PreCalcul,C1,C2)
                Stop = (norm(Rbefore-R,2)/(1+norm(Rbefore,2))<=self.Rtol) and (norm(Sbefore-S,2)/(1+norm(Sbefore,2))<=self.Stol)
            self.Stot[:,i] = S 
            self.Rtot[:,i] = R