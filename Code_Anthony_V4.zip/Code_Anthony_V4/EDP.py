# -*- coding: utf-8 -*-
"""
Created on Thu Feb  9 11:26:06 2023

@author: antho
"""

from Utile import Triplet
import numpy as np
from scipy.sparse import coo_matrix

class EDP:
    def __init__(self):
        """
        Construction d'une EDP du type C1*dt(f(x,t))+C2*Operateur(f(x,t)) = s(x,t)
        avec dt() la dérivation temporelle
        """
        self.Operateur = ""
        self.C1 = float()
        self.C2 = float()
    def getOperateur(self):
        return self.Operateur
    def getC1(self):
        return self.C1
    def getC2(self):
        return self.C2
    def Operateur(self,Op):
        self.Operateur = Op
    def C1(self,C1):
        self.C1 = C1
    def C2(self,C2):
        self.C2 = C2
        
class EDPsca(EDP):
    def __init__(self):
        self.TypeSource = ""
    def Masse(self,Triangles,PreCalcul):
        # Récupération des informations du maillage
        Tri = Triangles.Tri
        Nt = Triangles.Nt
        # Instanciation d'un Triplet
        t = Triplet()
        if EDPsca.getOperateur(self) == "LaplacienScalaire":
            for p in range(Nt):
                T = Tri[p]
                PC = PreCalcul[p]
                # Matrice de masse M élémentaire
                Melm = PC[3]/12*np.array([[2,1,1],[1,2,1],[1,1,2]])
                for i in range(3):
                    I = int(T[i][0]-1)
                    for j in range(3):
                        J = int(T[j][0]-1)
                        t.append(I,J,Melm[i,j])
            return coo_matrix(t.data)
        # A VOIR POUR LE FORMAT TOCSR
    def Rigidité(self,Triangles,PreCalcul):
        # Récupération des informations du maillage
        Tri = Triangles.Tri
        Nt = Triangles.Nt
        # Instanciation d'un Triplet
        t = Triplet()
        if EDPsca.getOperateur(self) == "LaplacienScalaire":
            for p in range(Nt):
                T = Tri[p]
                PC = PreCalcul[p]
                # Matrice de rigidité K élémentaire
                K22 = PC[0]/4/PC[3]
                K33 = PC[1]/4/PC[3]
                K23 = PC[2]/4/PC[3]
                Kelm = np.array([[K22+K33+2*K23,-K23-K22,-K23-K33],[-K23-K22,K22,K23],[-K23-K33,K23,K33]])
                for i in range(3):
                    I = int(T[i][0]-1)
                    for j in range(3):
                        J = int(T[j][0]-1)
                        t.append(I,J,Kelm[i,j])
            return coo_matrix(t.data)
        # A voir pour le format csr
    def Source(self,Amp):
        if self.TypeSource == "Constante":
            return Amp
