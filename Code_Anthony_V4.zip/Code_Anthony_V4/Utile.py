# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 11:11:50 2023

@author: antho
"""

class Triplet:
    def __init__(self):
        self.data = ([],([],[]))
    def __str__(self):
        return str(self.data)
    def append(self,I,J,val):
        # Ajoutes le triplet [I,J,val] dans self.data
        # COMMENTAIRE A FAIRE
        #self.data = (val,(I,J))
        self.data[0].append(val)
        self.data[1][0].append(I)
        self.data[1][1].append(J)
        
        
