# -*- coding: utf-8 -*-
"""
Created on Wed Feb  8 20:57:14 2023

@author: antho
"""

from Maillage import Mesh,Triangles
from Equation import EDPsca
from Resolution import PGD
from Source import diffusion2,diffusion3
from Traitement import PostTraitement

###################################################################################
"""
Main du Projet. Il permet d'exécuter les différentes méthodes de calculs.
"""
###################################################################################
"""
PRE-TRAITEMENT (A COMPILER UNE SEULE FOIS)
"""
# Récupération du maillage et précalcul 
Maill = Mesh("MySquare.msh")
Tri = Triangles(Maill)
PC = Tri.PreCalcul()
# Définition de l'équation aux dérivées partielles 
EquChaleur = EDPsca()
EquChaleur.C1 = 1.0
EquChaleur.C2 = 1.0
EquChaleur.Operateur = "LaplacienScalaire"
# Création des matrices de masse et de rigidité
M = EquChaleur.Masse(Tri,PC)
K = EquChaleur.Rigidité(Tri,PC)
###################################################################################
"""
Définition des paramètres pour la méthode PGD
"""
# Paramètres de calcul
TfinPGD = 1.0
NtempsPGD = 1500
ModePGD = [1,2,3,4,5,6]
MaxIterPGD = 300
TolPGD = 1e-13
ModesSource = 4 # Seulement pour diffusion3
# Création de la source
Srce = diffusion3(ModesSource,Maill,TfinPGD,NtempsPGD,EquChaleur.C1,EquChaleur.C2)
Srce.val = Srce.Crop(Srce.val,Tri)
"""
Définition des paramètres pour la méthode POD
"""

###################################################################################
"""
PROPER ORTHOGONAL DECOMPOSITION (POD)
"""

###################################################################################
"""
PROPER GENERALIZED DECOMPOSITION (PGD)
"""
PTpgd = PostTraitement(Srce.NameSource,ModePGD)
for Mode in ModePGD:
    RES = PGD(Tri.NnWOb,TfinPGD,NtempsPGD,Mode,MaxIterPGD,TolPGD)
    RES.Calcul(Srce.val,K,M,EquChaleur.C1,EquChaleur.C2)
    PTpgd.RecupInfoPGD(RES)
###################################################################################
"""
POST-TRAITEMENT
"""
PTpgd.AssemblageModePGD()
PTpgd.AddBoundary(Tri)
PTpgd.SolAnalytique(ModesSource,Maill,NtempsPGD,TfinPGD)
PTpgd.Erreur()
PTpgd.Affichage(Maill,TfinPGD,NtempsPGD)
PTpgd.result_plot(PTpgd.Sol,Maill,700)
for i in range(len(ModePGD)):
    PTpgd.result_plot(PTpgd.Ttot[i],Maill,700)