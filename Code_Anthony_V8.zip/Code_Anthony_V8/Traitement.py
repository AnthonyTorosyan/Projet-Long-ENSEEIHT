# -*- coding: utf-8 -*-
"""
Created on Sun Feb 19 21:52:47 2023

@author: antho
"""

import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
from numpy.linalg import norm

class PostTraitement:
    def __init__(self,NameSource,Modes):
        """
        Description
        ----------
        Cette classe est consacrée au post-traitement.

        Parameters
        ----------
        NameSource : Chaîne de caractères
            Nom de la source utilisée.
        Modes : Liste
            Liste contenant le nombre de modes à calculer pour chaque simulation.

        Returns
        -------
        None.
        """
        self.NameSource = NameSource
        self.Modes = Modes
        self.NbrSimu = len(Modes)
        self.Rtot = []
        self.Stot = []
        self.TtotWOb = []
        self.Ttot = []
        self.Sol = ()
        self.Err = []
        self.TpsCalcul = []
    def RecupInfoPGD(self,RES):
        self.Rtot.append(RES.Rtot)
        self.Stot.append(RES.Stot)
        self.TpsCalcul.append(RES.TpsCalcul)
    def result_plot(self,Ad,Maill,t):
        """
        Description
        ----------
        Méthode permettant de tracer les graphes.

        Parameters
        ----------
        Ad : array([Nn,Ntemps])
            Matrice de la solution calculée.
        Maill : Class
            Objet de classe Maillage.
        t : int
            Itération temporelle affichée par le graphe.

        Returns
        -------
        None.
        """
        triang = mtri.Triangulation(Maill.x, Maill.y)
        fig = plt.figure()
        ax = fig.add_subplot(1,1,1, projection='3d')
        ax.plot_trisurf(triang, Ad.T[t], cmap='jet')
        ax.scatter(Maill.x,Maill.y,Ad.T[t], marker='.', s=10, c="black", alpha=0.5)
        ax.view_init(elev=60, azim=-45)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('T')
        plt.show()
    def AssemblageModePGD(self):
        """
        Description
        ----------
        Cette méthode assemble les modes temporelles et spatiaux de la méthode PGD dans une matrice.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            Rtot_i = self.Rtot[i]
            Stot_i = self.Stot[i]
            NnWOb = np.shape(Rtot_i)[0]
            Ntemps = np.shape(Stot_i)[0]
            T = np.zeros([NnWOb,Ntemps])
            for j in range(Ntemps):
                T[:,j] = Rtot_i@Stot_i[j,:]
            self.TtotWOb.append(T)
    def AddBoundary(self,Tri,Boundary = 0):
        """
        Description
        ----------
        Cette méthode ajoute les bords dans la matrice de la solution.

        Parameters
        ----------
        Tri : Class
            Objet de classe Triangles.
        Boundary : float, optional
            Valeur sur les bords (conditions de type Dirichlet). Par défaut, c'est 0.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            T = self.TtotWOb[i]
            Ntemps = np.shape(T)[1]
            Twb = Boundary*np.ones([Tri.Nn,Ntemps])
            for j in range(Ntemps):
                Twb[Tri.Nn-Tri.NnWOb:Tri.Nn,j] = T[:,j]
            self.Ttot.append(Twb)
    def SolAnalytique(self,M,Maill,Ntemps,Tfin):
        """
        Description
        ----------
        Calcul de la solution analytique de l'EDP.

        Parameters
        ----------
        M : int
            Nombre de modes pour la solution Diffusion3.
        Maill : Class
            Objet de classe Maillage.
        Ntemps : int
            Nombre de points dans la discrétisation temporelle.
        Tfin : float
            Temps final.

        Returns
        -------
        None.
        """
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        Y = Maill.y
        if self.NameSource == "Diffusion2":
            self.Sol = (np.tensordot(np.sin(2*np.pi*(X-1))*np.sin(2*np.pi*(Y-1)),np.sin(np.pi*t),axes=0))
        if self.NameSource == "Diffusion3":
            Nn = int(np.max(Maill.Noeuds))
            self.Sol = np.zeros([Nn,Ntemps])
            for m in range(M):
                self.Sol = self.Sol+np.tensordot(np.sin(2*np.pi*(X-1))*np.sin(2*np.pi*(Y-1))*np.cos(2*np.pi*m/M*X)*np.cos(2*np.pi*m/M*Y),np.sin(np.pi*t)*np.cos(2*np.pi*m/M*t),axes=0)
    def Erreur(self):
        """
        Description
        ----------
        Cette méthode permet de calculer l'erreur relative entre les solutions 
        calculée et analytique pour chaque pas de temps.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            Err_i = []
            Ttot_i = self.Ttot[i]
            Ntemps = np.shape(Ttot_i)[1]
            for j in range(Ntemps):
                Err_i.append(norm(Ttot_i[:,j]-self.Sol[:,j],2)/(1+norm(self.Sol[:,j],2)))
            self.Err.append(Err_i)
    def Affichage(self,Maill,Tfin,Ntemps):
        """
        Description
        ----------
        Affichage du temps de calcul, et des informations sur la norme relative pour chaque simulation.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            print('----------------------------------------------------',end='\n')
            print('------------- NOMBRE DE MODES: '+str(self.Modes[i])+' -------------------',end='\n')
            print('----------------------------------------------------',end='\n \n')
            print('Temps de calcul', self.TpsCalcul[i],end='\n \n')
            print("Minimum de l'erreur relative",np.min(self.Err[i][1:]),end='\n')
            print("Moyenne de l'erreur relative",np.mean(self.Err[i]),end='\n')
            print("Maximum de l'erreur relative",np.max(self.Err[i]),end='\n \n')
        if self.NbrSimu == 1:
            t = [i for i in range(Ntemps)]
            t = Tfin/(Ntemps-1)*np.array(t)
            triang = mtri.Triangulation(Maill.x, Maill.y)
            # Affichage des modes temporels
            fig,ax = plt.subplots()
            for i in range(self.Modes[0]):
                ax.plot(t,self.Stot[0][:,i],label="Mode spatial n°"+str(i+1))
            ax.set_xlabel("t")
            ax.set_ylabel("Amplitudes des modes temporels")
            ax.legend()
            plt.grid()
            plt.show()
            # Affichage des modes spatiaux
            Nn = int(np.max(Maill.Noeuds))
            NnWOb = np.size(Maill.NoeudsNotBoundary)
            RtotWb = np.zeros([Nn,self.Modes[0]])
            for i in range(self.Modes[0]):
                RtotWb[Nn-NnWOb:Nn,i] = self.Rtot[0][:,i]
            fig, ax = plt.subplots(1,self.Modes[0],figsize=(10,5),subplot_kw={'projection': '3d'})
            for i in range(self.Modes[0]):
                ax[i].plot_trisurf(triang,RtotWb[:,i],cmap='jet')
                ax[i].set_xlabel('X')
                ax[i].set_ylabel('Y')
                ax[i].set_zlabel('Amplitude')
                ax[i].set_title("Mode spatial n°"+str(i+1))
            plt.show()
        elif self.NbrSimu > 1:
            MeanErr = np.zeros(self.NbrSimu)
            for i in range(self.NbrSimu):
                MeanErr[i] = np.mean(self.Err[i][:])
            fig,ax = plt.subplots()
            ax.plot(self.Modes,MeanErr,"k:o")
            ax.set_xlabel("Nombre de modes calculés")
            ax.set_ylabel("Erreur")
            plt.grid()
            plt.show()