# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 12:52:58 2023

@author: antho
"""

class Mesh:
    def __init__(self):
        Point[] points
        Segment[] segments
        Triangle[] triangles
        int Npts,Nseg,Ntri
    def __str__(self):
        return
    def GmshToMesh(self,filename=-1):
        
    def getElements(self,dim,physical_tag=-1):
        
    def getPoints(self,dim,physical_tag=-1):
        
        
class Point(Mesh):
    N = ???
    name = "Point"
    def __init__(self,x,y):
        int id 
        float x,y
    
class Segment(Mesh):
    N = ???
    name = "Segment"
    def __init__(self,Point[],id):
        int id 
        Point[] p
        int physical_tag
    def area(self):
        
    def jac(self):
        
        
class Triangle(Mesh):
    N = ???
    name = "Triangle"
    def __init__(self,Point[],id):
        int id 
        Point[] p
        int physical_tag
    def area(self):
        
    def jac(self):
        
        