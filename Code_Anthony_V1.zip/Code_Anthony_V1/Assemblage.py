# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 11:11:50 2023

@author: antho
"""

from scipy.sparse import coo_matrix
import numpy as np

class Triplet:
    def __init__(self):
        self.data = ([],([],[]))
    def __str__(self):
        return str(self.data)
    def append(self,I,J,val):
        # Ajoutes le triplet [I,J,val] dans self.data
        # COMMENTAIRE A FAIRE
        self.data[0].append(val)
        self.data[1][0].append(I)
        self.data[1][1].append(I)
        #self.data = (val,(I,J))
        
# class Assemblage:
#     def __init__(self):
                
        
        
        
        
        
        
        
        
        
        
        
        
##### Test #####

# t = Triplet()
# val = np.array([1.1,2,1,2.3,0.5,2,2])
# I = np.array([0,0,1,2,3,3,3])
# J = np.array([0,3,1,2,0,1,3])
# t.append(I,J,val)
# A = coo_matrix(t.data)
# A = A.tocsr()
# print(A.toarray())
