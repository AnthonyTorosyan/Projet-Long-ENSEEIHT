# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 13:42:49 2023

@author: arabej
"""

import gmsh
import numpy as np

# Initialiser GMSH
gmsh.initialize()

# Charger un fichier .msh
gmsh.open("MySquare.msh")

# # Récupérer les noeuds
# nodes = gmsh.model.mesh.getNodes()

# # Récupérer les éléments
# elements = gmsh.model.mesh.getElements()

# Récupère les noeuds et coordonnées pour chaque triangle
test = gmsh.model.mesh.getNodesByElementType(2)
Noeuds = test[0]
Coord = test[1]
Nt = int(np.size(Noeuds)/3)
Triangle = ()
j = 0
for i in range(Nt):
    # Triangle.append([[Noeuds[i],Coord[i:i+2]],[Noeuds[i+1],Coord[i+3:i+5]],[Noeuds[i+2],Coord[i+6:i+8]]])
    i = i+3*j
    TriInfo = [[Noeuds[i],Coord[i:i+3]],[Noeuds[i+1],Coord[i+4:i+7]],[Noeuds[i+2],Coord[i+8:i+11]]]
    Triangle = Triangle+tuple(TriInfo)
    j = i

# Finaliser GMSH
gmsh.finalize()
