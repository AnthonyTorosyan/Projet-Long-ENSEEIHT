# -*- coding: utf-8 -*-
"""
Created on Wed Feb  8 11:02:16 2023

@author: antho
"""

import numpy as np
from numpy.linalg import norm
from Assemblage import Triplet

# T est la liste des triangles

# récupération des longueurs segments et des aires
# Nt = len(T)
# for p in range(Nt):
#     Tp = T[p]
#     S1S3 = norm(T[p,2,1:2]-T[p,0,1:2],2)
#     S2S1 = norm(T[p,0,1:2]-T[p,1,1:2],2)
#     psS1S3S2S1 = np.dot(T[p,2,1:2]-T[p,0,1:2],T[p,0,1:2]-T[p,1,1:2])

# le triplet (matrice creuse)
t = Triplet()

# paramètres de l'EDP
C1 = 1
C2 = 1

# Nombre de triangles
Nt = len(T)
for p in range(Nt):
    # récupération des longueurs segments et des aires
    S1S3 = norm(T[p,2,1:2]-T[p,0,1:2],2)**2
    S2S1 = norm(T[p,0,1:2]-T[p,1,1:2],2)**2
    psS1S3S2S1 = np.dot(T[p,2,1:2]-T[p,0,1:2],T[p,0,1:2]-T[p,1,1:2])
    Aire = 0.5*norm(np.cross(T[p,2,1:2]-T[p,0,1:2],T[p,0,1:2]-T[p,1,1:2]),2)
    # Matrice de rigidité K
    K22 = S1S3**2/4/Aire
    K33 = S2S1**2/4/Aire
    K23 = psS1S3S2S1/4/Aire
    K = np.array([[K22+K33+K23,-K23-K22,-K23-K33],[-K23-K22,K22,K23],[-K23-K33,K23,K33]])
    # Matrice de masse M
    M = Aire/12*np.array([2,1,1],[1,2,1],[1,1,2])
    # Matrice élémentaire totale
    A = C1*K+C2*M
    for i in range(3):
        #I = loc2glob(T,p,i)
        I = T[p,i,0]
        for j in range(3):
            #J = loc2glob(T,p,j)
            J = T[p,j,0]
            if A[i,j] != 0:
                t.append(I,J,A[i,j])
            
            