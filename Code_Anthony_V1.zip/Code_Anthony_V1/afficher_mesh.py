# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 13:45:56 2023

@author: arabej
"""

import numpy as np
import gmsh
import gmsh_api
# Initialiser GMSH
gmsh.initialize()

# Ouvrir le fichier de maillage
gmsh.open("MySquare.msh")

# Récupérer les coordonnées des noeuds
node_coordinates = np.array(gmsh.model.mesh.getNodes(), dtype=object)
# print("Node coordinates shape:", node_coordinates.shape)
# print("Node coordinates size:", len(node_coordinates))
print('node_coordinates=',node_coordinates[1])
mesh = gmsh_api.Mesh.from_gmsh(gmsh) # pour un affichage plus clair 
# print(mesh.nodes)
# print('nombre nodes=',len(node_coordinates[0]))
# print('nombre coordones=',len(node_coordinates[1]))
# print(node_coordinates[1][0]);print(node_coordinates[1][1]);print(node_coordinates[1][2])
# Récupérer les indices des noeuds pour chaque triangle
element_type, tag, element_node_index = gmsh.model.mesh.getElements(dim=2)
# print('element_type=',element_type)
# print('tag=',tag)
print('element_node_index=',element_node_index)
# print('element_type size=',len(element_type))
# print('tag size=',len(tag))
print('element_node_index size=',len(element_node_index[0]))
# print(mesh.elements)

triangles = []
for i in range(len(element_node_index)):
    triangle = [element_node_index[i], node_coordinates[1][element_node_index[i][0]],
                node_coordinates[1][element_node_index[i][1]],
                node_coordinates[1][element_node_index[i][2]]]
    triangles.append(triangle)

print('triangles=',triangles)



# Finaliser GMSH
gmsh.finalize()





