# -*- coding: utf-8 -*-
"""
Created on Wed Feb  8 12:48:25 2023

@author: antho
"""

def loc2glob(T,NumT,NumN):
    
    # T est la liste de tout les triangles
    # NumT est le numéro du triangle
    # NumN est le numéro local du noeud
    
    return T[NumT,NumN,0]