# -*- coding: utf-8 -*-
"""
Created on Thu Feb  9 17:39:56 2023

@author: antho
"""

import numpy as np
from numpy.linalg import norm

class Resolution:
    def __init__(self):
        self.Methode = ""
    def getMethode(self):
        return self.Methode
    def Methode(self,Meth):
        self.Methode = Meth
        
class PGD(Resolution):
    def __init__(self):
        self.Tfin = float()
        self.Ntemps = int()
        self.dt = self.Tfin/self.Ntemps
        self.Mode = int()
        self.Rtol = float()
        self.Stol = float()
    def Sn(self,Tri):
        
    def Rn(self,Tri,S,AireD,Source,Stot):
        # Calcul des coefficients
        AS = np.sum((S[1:self.Ntemps]-S[:self.Ntemps-1])*S[:self.Ntemps-1])
        BS = np.sum(S[:self.Ntemps-1]**2*self.dt)
        CR1 = Source*AireD*np.sum(S[:self.Ntemps]*self.dt)
        CR2interm = np.transpose(Stot[1:self.Ntemps,:]-Stot[:self.Ntemps-1,:])@S[:self.Ntemps-1]
        
        CR2 = 
    def Calcul(self,Tri):
        Stot = np.zeros([self.Ntemps,self.Mode])
        Rtot = np.zeros([Tri.Nt,self.Mode])
        for i in range(self.Mode):
            S = np.ones(self.Ntemps)
            Stop = False
            while Stop == False:
                PGD.Rn(self,Tri)
                PGD.Sn(self,Tri)
                Stop = (norm()<=self.Rtol) and (norm()<=self.Stol)
            Stot[:,i] = S 
            Rtot[:,i] = R