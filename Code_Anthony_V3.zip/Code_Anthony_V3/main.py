# -*- coding: utf-8 -*-
"""
Created on Wed Feb  8 20:57:14 2023

@author: antho
"""

from Maillage import Mesh,Triangles
from EDP import EDPsca

###################################################################################
"""

"""
###################################################################################
"""PRE-TRAITEMENT (A COMPILER UNE SEULE FOIS)"""
# Récupération du maillage et précalcul 
Maill = Mesh("MySquare.msh")
Tri = Triangles(Maill.Noeuds,Maill.Coord)
PC = Tri.PreCalcul()
# Définition de l'équation aux dérivées partielles 
EquChaleur = EDPsca()
EquChaleur.C1(1.0)
EquChaleur.C2(1.0)
EquChaleur.Operateur("LaplacienScalaire")
# Création des matrices de masse et de rigidité
M = EquChaleur.Masse(Tri,PC)
K = EquChaleur.Rigidité(Tri,PC)
# Création de la source
EquChaleur.TypeSource = "Constante"
Amplitude = 1
S = EquChaleur.Source(Amplitude)
###################################################################################
"""PROPER ORTHOGONAL DECOMPOSITION"""

###################################################################################
"""PROPER GENERALIZED DECOMPOSITION"""

###################################################################################
"""POST-TRAITEMENT"""
