# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 11:11:50 2023

@author: antho
"""

import numpy as np

class Triplet:
    def __init__(self):
        self.data = ([],([],[]))
    def __str__(self):
        return str(self.data)
    def append(self,I,J,val):
        # Ajoutes le triplet [I,J,val] dans self.data
        # COMMENTAIRE A FAIRE
        #self.data = (val,(I,J))
        self.data[0].append(val)
        self.data[1][0].append(I)
        self.data[1][1].append(J)
        
class Calcul:
    def __init__(self,Ntemps,NnWOb):
        self.CS2 = np.zeros(Ntemps)
        self.StockageCS2_dSmodes = np.zeros(Ntemps)
        self.StockageCS2_Produit = np.zeros(NnWOb)
        self.CS3 = np.zeros(Ntemps)
        self.StockageCS3_Smodes = np.zeros(Ntemps)
        self.StockageCS3_Produit = np.zeros(NnWOb)
        self.StockageCR2 = ()
        self.StockageCR3 = ()
    def CalculCS2(self,m,Save,R,Rtot,Stot,M):
        if Save == True:
            if m != 0:
                # En espace
                Rmode = Rtot[:,m-1]
                self.StockageCS2_Produit = np.concatenate([[self.StockageCS2_Produit],[M@Rmode]])
                # En temps
                Smode = Stot[:,m-1]
                dSmode = np.gradient(Smode)
                self.StockageCS2_dSmodes = np.concatenate([[self.StockageCS2_dSmodes],[dSmode]])
        SpaceInt = R@np.transpose(self.StockageCS2_Produit)
        self.CS2 = np.dot(np.transpose(self.StockageCS2_dSmodes),SpaceInt)
    def CalculCS3(self,m,Save,R,Rtot,Stot,K):
        if Save == True:
            if m != 0:
                # En espace
                Rmode = Rtot[:,m-1]
                self.StockageCS3_Produit = np.concatenate([[self.StockageCS3_Produit],[K@Rmode]])
                # En temps
                Smode = Stot[:,m-1]
                self.StockageCS3_Smodes = np.concatenate([[self.StockageCS3_Smodes],[Smode]])
        SpaceInt = R@np.transpose(self.StockageCS3_Produit)
        self.CS3 = np.dot(np.transpose(self.StockageCS3_Smodes),SpaceInt)
    def MethodeTrapeze(self,F,dt,Ntemps):
        """
        Intégration d'une fonction d'une variable par la méthode des trapèzes
        """
        return dt*((F[0]+F[-1])/2+np.sum(F[1:Ntemps-1]))