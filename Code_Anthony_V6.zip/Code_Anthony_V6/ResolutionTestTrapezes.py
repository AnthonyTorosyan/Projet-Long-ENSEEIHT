# -*- coding: utf-8 -*-
"""
Created on Thu Feb 16 10:25:02 2023

@author: antho
"""

from Utile import Triplet
import numpy as np
from numpy.linalg import norm
from scipy.sparse.linalg import spsolve
from scipy.sparse import coo_matrix

class Resolution:
    def __init__(self):
        self.Methode = ""
    def getMethode(self):
        return self.Methode
    def Methode(self,Meth):
        self.Methode = Meth
        
class PGD(Resolution):
    def __init__(self,Triangles,Tfin,Ntemps,Mode,MaxIter,Rtol,Stol):
        self.Tfin = Tfin
        self.Ntemps = Ntemps
        self.dt = self.Tfin/float(self.Ntemps-1)
        self.Mode = Mode
        self.MaxIter = MaxIter
        self.Rtol = Rtol
        self.Stol = Stol
        self.Stot = np.zeros([self.Ntemps,self.Mode])
        self.Rtot = np.zeros([Triangles.NnWOb,self.Mode])
    def CalculSn(self,Triangles,R,Source,PreCalcul,K,M,C1,C2):
        # Calcul des coefficients
        AR = C2*R@K@R
        print("AR",AR)
        BR = C1*R@M@R
        print("BR",BR)
        CS1 = np.zeros(self.Ntemps)
        for i in range(self.Ntemps):
            CS1[i] = Source[:,i]@M@R
        VectInt = np.zeros(self.Mode)
        dStot = np.zeros([self.Ntemps,self.Mode])
        for i in range(self.Mode):
            # En espace
            Rmode = self.Rtot[:,i]
            VectInt[i] = Rmode@M@R
            # En temps
            Smode = self.Stot[:,i]
            dSmode = np.gradient(Smode)
            dStot[:,i] = dSmode
        CS2 = dStot@VectInt
        VectInt = np.zeros(self.Mode)
        for i in range(self.Mode):
            Rmode = self.Rtot[:,i]
            VectInt[i] = Rmode@K@R
        CS3 = C2*self.Stot@VectInt
        CS = CS1-CS2-CS3
        print("norme CS",norm(CS,2))
        # Schéma d'Euler explicite
        # S = np.zeros(self.Ntemps)
        # for i in range(self.Ntemps-1):
        #     S[i+1] = S[i]+self.dt/BR*(CS[i]-AR*S[i])
        # Schéma d'Euler implicite
        S = np.zeros(self.Ntemps)
        for i in range(self.Ntemps-1):
            S[i+1] = 1/(AR+BR/self.dt)*(CS[i+1]+BR/self.dt*S[i])
        # Schéma Crank Nicholson
        # S = np.zeros(self.Ntemps)
        # Cste = 1/(1/self.dt+AR/2/BR)
        # for i in range(self.Ntemps-1):
        #     S[i+1] = Cste*(S[i]/self.dt+1/2/BR*(CS[i+1]+CS[i]-AR*S[i]))
        return S
    def CalculRn(self,Triangles,S,Source,PreCalcul,K,M,C1,C2):
        # Calcul des coefficients
        Int = S**2
        AS = self.dt*((Int[0]+Int[-1])/2+np.sum(Int[1:self.Ntemps-1]))
        print("AS",AS)
        Int = np.gradient(S)*S
        BS = self.dt*((Int[0]+Int[-1])/2+np.sum(Int[1:self.Ntemps-1]))
        print("BS",BS)
        CR1 = np.zeros(Triangles.NnWOb)
        for i in range(Triangles.NnWOb):
            Int = Source[i,:]*S
            CR1[i] = self.dt*((Int[0]+Int[-1])/2+np.sum(Int[1:self.Ntemps-1]))
        IntTot = np.zeros(self.Mode)
        for i in range(self.Mode):
            # En temps
            Smode = self.Stot[:,i]
            dSmode = np.gradient(Smode)
            Int = dSmode*S
            IntTot[i] = self.dt*((Int[0]+Int[-1])/2+np.sum(Int[1:self.Ntemps-1]))
        CR2 = self.Rtot@IntTot
        IntTot = np.zeros(self.Mode)
        for i in range(self.Mode):
            # En temps
            Smode = self.Stot[:,i]
            Int = Smode*S
            IntTot[i] = self.dt*((Int[0]+Int[-1])/2+np.sum(Int[1:self.Ntemps-1]))
        CR3 = self.Rtot@IntTot
        CR = M@(CR1-C1*CR2)-C2*K@CR3
        print("norme CR",norm(CR,2))
        return spsolve(C2*AS*K+C1*BS*M,CR)
    def Calcul(self,Triangles,Source,PreCalcul,K,M,C1,C2):
        for i in range(self.Mode):
            S = np.ones(self.Ntemps)
            R = np.zeros(Triangles.NnWOb)
            Stop = False
            Iter = 0
            while (Stop == False) and (Iter <= self.MaxIter):
                Iter = Iter+1
                print("Itération",Iter)
                Rbefore = R
                Sbefore = S
                R = PGD.CalculRn(self,Triangles,S,Source,PreCalcul,K,M,C1,C2)
                print("norme R",norm(R,2),end="\n \n")
                S = PGD.CalculSn(self,Triangles,R,Source,PreCalcul,K,M,C1,C2)
                print("norme S",norm(S,2),end="\n \n") 
                Stop = norm(np.tensordot(R,S,axes=0)-np.tensordot(Rbefore,Sbefore,axes=0),'fro')/(1+norm(np.tensordot(Rbefore,Sbefore,axes=0),'fro')) <= 1e-3
                print("Norme Résidu",norm(np.tensordot(R,S,axes=0)-np.tensordot(Rbefore,Sbefore,axes=0),'fro')/(1+norm(np.tensordot(Rbefore,Sbefore,axes=0),'fro')))
                print("Stop",Stop,end="\n \n")
            self.Stot[:,i] = S 
            self.Rtot[:,i] = R