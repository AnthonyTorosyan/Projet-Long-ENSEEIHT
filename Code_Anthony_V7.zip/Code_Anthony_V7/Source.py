# -*- coding: utf-8 -*-
"""
Created on Thu Feb 16 11:22:42 2023

@author: antho
"""

import numpy as np

class Source:
    def Crop(self,SourceMatrix,Triangles):
        """
        Description
        ----------
        Cette fonction permet d'enlever les bords dans le vecteur Source

        Parameters
        ----------
        SourceMatrix : array([NnWOb,Ntemps])
            Matrice contenant toutes les valeurs de la source.
        Triangles : Class
            Classe contenant les informations sur les triangles du maillage.

        Returns
        -------
        array([Nn-NnWOb,Ntemps])
            Matrice des valeurs de la source sans les bords.
        """
        return SourceMatrix[Triangles.Nn-Triangles.NnWOb:Triangles.Nn,:] 
        
class constante(Source):
    def __init__(self,Amp,Maill,Ntemps):
        """
        Description
        ----------
        Permet d'obtenir une source constante.

        Parameters
        ----------
        Amp : float
            Amplitude de la source.
        Maill : Class
            Objet de classe Maillage.
        Ntemps : int
            Nombre de points dans la discrétisation en temps.

        Returns
        -------
        None.
        """
        self.val = Amp*np.ones([Maill.Nn,Ntemps])
    def getval(self):
        return self.val 
       
class diffusion1(Source):
    def __init__(self,Maill,Tfin,Ntemps):
        """
        Description
        ----------
        Calcul de la source 1+2*x*t.

        Parameters
        ----------
        Maill : Class
            Objet de classe Maillage.
        Tfin : float
            Temps final.
        Ntemps : int
            Nombre de points dans la discrétisation en temps.

        Returns
        -------
        None.
        """
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        self.val = 1.0+2*np.tensordot(X,t,axes=0)
    def getval(self):
        return self.val
                
# class diffusion2(Source):
#     def __init__(self,Maill,Tf,Npas):
#         n=max(Maill.Noeuds)
#         s=np.zeros((n,Npas))
#         for j in range(Npas):
#             t=j*Tf/(Npas-1)
#             L=[]
#             for i in range (len(Maill.Noeuds)):
#                 if Maill.Noeuds[i] not in L:
#                     x=Maill.Coord[int(3*i)]
#                     y=Maill.Coord[int(3*i+1)]
#                     ut=np.sin(np.pi*x)*np.sin(np.pi*y)-1/2*np.sin(np.pi*x)*np.sin(2*np.pi*y)+np.pi/2*np.sin(2*np.pi*x)*np.sin(np.pi*y)*np.cos(np.pi*t)+2*np.pi/3*np.sin(2*np.pi*x)*np.sin(2*np.pi*y)*np.cos(2*np.pi*t)+4*np.pi/5*np.sin(4*np.pi*x)*np.sin(4*np.pi*y)*np.cos(4*np.pi*t)
#                     us=-2*np.pi**2*np.sin(np.pi*x)*np.sin(np.pi*y)*t-5/4*np.pi**2*np.sin(np.pi*x)*np.sin(2*np.pi*y)*(1-t)-3/4*np.pi**2*np.sin(2*np.pi*x)*np.sin(np.pi*y)*np.sin(np.pi*t)-8/3*np.pi**2*np.sin(2*np.pi*x)*np.sin(2*np.pi*y)*np.sin(2*np.pi*t)-32/5*np.pi**2*np.sin(4*np.pi*x)*np.sin(4*np.pi*y)*np.sin(4*np.pi*t)
#                     s[int(Maill.Noeuds[i]-1),j]=ut-us
#                     print("s",s[int(Maill.Noeuds[i]-1),j])
#                     L=L+[Maill.Noeuds[i]]
#         self.val=s

class diffusion3(Source):
    def __init__(self,Maill,Tfin,Ntemps,C1,C2):
        """
        Description
        ----------
        Calcul de la source pi*sin(pi/L*(x-L))*sin(pi/L*(y-L))*(C1*cos(pi*t)+2*C2*pi/L*sin(pi*t))

        Parameters
        ----------
        Maill : Class
            Onjet de classe Maillage.
        Tfin : float
            Temps final.
        Ntemps : int
            Nombre de points dans la discrétisation en temps.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        None.
        """
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        Y = Maill.y
        L = np.max(Maill.Coord)
        self.val = np.pi*np.tensordot(np.sin(np.pi/L*(X-L))*np.sin(np.pi/L*(Y-L)),C1*np.cos(np.pi*t)+2*C2*np.pi/L/L*np.sin(np.pi*t),axes=0)