# -*- coding: utf-8 -*-
"""
Created on Thu Feb 16 19:05:47 2023

@author: antho
"""

from Utile import Coefficient
import numpy as np
from numpy.linalg import norm
from scipy.sparse.linalg import spsolve
        
class PGD:
    def __init__(self,NnWOb,Tfin,Ntemps,Mode,MaxIter,Tol):
        """
        Description
        ----------
        Classe permettant d'utiliser la méthode Proper Generalized Decomposition.
        
        Parameters
        ----------
        NnWOb : int
            Nombre de noeuds à l'intérieur du maillage.
        Tfin : float
            Temps final du calcul.
        Ntemps : int
            Nombre de points en temps.
        Mode : int
            Nombre de modes à calculer.
        MaxIter : int
            Maximum d'itérations pour la recherche des modes.
        Tol : float
            Tolérance pour la convergence des modes.

        Returns
        -------
        None.
        """
        self.NnWOb = NnWOb
        self.Tfin = Tfin
        self.Ntemps = Ntemps
        self.dt = self.Tfin/float(self.Ntemps-1)
        self.Mode = Mode
        self.MaxIter = MaxIter
        self.Tol = Tol
        self.Coeff = Coefficient(self.Ntemps,self.dt,self.NnWOb,self.Mode)
        self.Stot = np.zeros([self.Ntemps,self.Mode])
        self.Rtot = np.zeros([self.NnWOb,self.Mode])
    def CalculSm(self,R,Source,K,M,C1,C2):
        """
        Description
        ----------
        Calcul de S_m(t) à l'itération Iter.

        Parameters
        ----------
        R : array(NnWOb)
            R_m(x) à l'itération Iter.
        Source : array([NnWOb,Ntemps])
            Source de l'EDP.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        S : array(Ntemps)
            S_m(t) à l'itération Iter.
        """
        # Calcul des coefficients
        AR = C2*R@K@R
        BR = C1*R@M@R
        # Calcul du second membre
        CS = self.Coeff.CS(Source,R,self.Stot,self.Rtot,M,K,C1,C2)
        # Schéma d'Euler implicite
        S = self.Coeff.EulerImplicite(CS,AR,BR,self.dt,self.Ntemps)
        # Quelques affichages
        print("AR",AR)
        print("BR",BR)
        print("CS",norm(CS,2))
        print("norme S",norm(S,2),end="\n \n") 
        return S
    def CalculRm(self,S,Source,K,M,C1,C2):
        """
        Description
        ----------
        Calcul de R_m(x) à l'itération Iter.

        Parameters
        ----------
        S : array(Ntemps)
            S_m(t) à l'itération Iter-1.
        Source : array([NnWOb,Ntemps])
            Source de l'EDP.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        R : array(NnWOb)
            R_m(x) à l'itération Iter.
        """
        # Calcul des coefficients
        AS = self.Coeff.MethodeTrapeze(S**2,self.dt,self.Ntemps)
        BS = self.Coeff.MethodeTrapeze(np.gradient(S)*S,self.dt,self.Ntemps)
        # Calcul du second membre
        CR = self.Coeff.CR(Source,S,self.Stot,self.Rtot,M,K,C1,C2)
        # Résolution du système linéaire
        R = spsolve(C2*AS*K+C1*BS*M,CR)
        # Quelques affichages
        print("AS",AS)
        print("BS",BS)
        print("CR",norm(CR,2))
        print("norme R",norm(R,2),end="\n \n")
        return R
    def Calcul(self,Source,K,M,C1,C2):
        """
        Description
        ----------
        Algorithme de la méthode PGD

        Parameters
        ----------
        Source : array([NnWOb,Ntemps])
            Source de l'EDP.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        None.
        """
        for m in range(self.Mode):
            S = np.ones(self.Ntemps)
            R = np.zeros(self.NnWOb)
            Stop = False
            Iter = 0
            while (Stop == False) and (Iter <= self.MaxIter):
                Iter = Iter+1
                Rbefore = R
                Sbefore = S
                # Calcul du mode m de l'itération Iter-1 (pour le critère d'arrêt)
                M_mbefore = np.tensordot(Rbefore,Sbefore,axes=0)
                # Calcul de R_m à l'itération Iter
                R = PGD.CalculRm(self,S,Source,K,M,C1,C2)
                # Calcul de S_m à l'itération Iter
                S = PGD.CalculSm(self,R,Source,K,M,C1,C2)
                # Calcul du mode m de l'itération Iter (pour le critère d'arrêt)
                M_m = np.tensordot(R,S,axes=0)
                # Calcul de la norme du résidu pour la convergence
                NormeResidu = norm(M_m-M_mbefore,'fro')/(1+norm(M_mbefore,'fro'))
                Stop = NormeResidu <= self.Tol
                # Quelques affichages
                print("Itération",Iter)
                print("Norme Résidu",NormeResidu)
                print("Stop",Stop,end="\n \n")
            # Enregistrement du mode
            self.Stot[:,m] = S 
            self.Rtot[:,m] = R