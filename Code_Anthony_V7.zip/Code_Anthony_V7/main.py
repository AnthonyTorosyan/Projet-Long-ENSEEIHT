# -*- coding: utf-8 -*-
"""
Created on Wed Feb  8 20:57:14 2023

@author: antho
"""

from Maillage import Mesh,Triangles
from Equation import EDPsca
from Resolution import PGD
from Source import diffusion3
from Traitement import PostTraitement

###################################################################################
"""
Main du Projet. Il permet d'exécuter les différentes méthodes de calculs.
"""
###################################################################################
"""
PRE-TRAITEMENT (A COMPILER UNE SEULE FOIS)
"""
# Récupération du maillage et précalcul 
Maill = Mesh("MySquare.msh")
Tri = Triangles(Maill)
PC = Tri.PreCalcul()
# Définition de l'équation aux dérivées partielles 
EquChaleur = EDPsca()
EquChaleur.C1 = 1.0
EquChaleur.C2 = 1.0
EquChaleur.Operateur = "LaplacienScalaire"
# Création des matrices de masse et de rigidité
M = EquChaleur.Masse(Tri,PC)
K = EquChaleur.Rigidité(Tri,PC)
###################################################################################
"""
Définition des paramètres pour la méthode PGD
"""
# Paramètres de calcul
TfinPGD = 1.0
NtempsPGD = 1500
ModePGD = 1
MaxIterPGD = 50
TolPGD = 1e-13
# Création de la source
Srce = diffusion3(Maill,TfinPGD,NtempsPGD,EquChaleur.C1,EquChaleur.C2)
Srce.val = Srce.Crop(Srce.val,Tri)
"""
Définition des paramètres pour la méthode POD
"""

###################################################################################
"""
PROPER ORTHOGONAL DECOMPOSITION (POD)
"""

###################################################################################
"""
PROPER GENERALIZED DECOMPOSITION (PGD)
"""
RES = PGD(Tri.NnWOb,TfinPGD,NtempsPGD,ModePGD,MaxIterPGD,TolPGD)
RES.Calcul(Srce.val,K,M,EquChaleur.C1,EquChaleur.C2)
###################################################################################
"""
POST-TRAITEMENT
"""
PT = PostTraitement("Diffusion3")
Ttot = PT.AssemblageModePGD(RES)
Ttot = PT.AddBoundary(Tri,RES,Ttot)
Sol = PT.SolAnalytique(Maill,NtempsPGD, TfinPGD)
PT.result_plot(Sol,Maill,1200)
PT.result_plot(Ttot,Maill,1200)