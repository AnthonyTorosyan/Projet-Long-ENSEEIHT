# -*- coding: utf-8 -*-
"""
Created on Sun Feb 19 21:52:47 2023

@author: antho
"""

import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np

class PostTraitement:
    def __init__(self,NameSource):
        """
        Description
        ----------
        Classe permettant de traiter les données après les calculs.

        Parameters
        ----------
        NameSource : Chaîne de caractères.
            Nom de la source utilisée lors du calcul.

        Returns
        -------
        None.
        """
        self.NameSource = NameSource
    def result_plot(self,Ad,Maill,t):
        """
        Description
        ----------
        Méthode permettant de tracer les graphes.

        Parameters
        ----------
        Ad : array([Nn,Ntemps])
            Matrice de la solution calculée.
        Maill : Class
            Objet de classe Maillage.
        t : int
            Itération temporelle affichée par le graphe.

        Returns
        -------
        None.
        """
        L=[]
        x=[0 for i in range (max(Maill.Noeuds))]
        y=[0 for i in range (max(Maill.Noeuds))]
        for i in range (len(Maill.Noeuds)):           
            if Maill.Noeuds[i] not in L:
                x[int(Maill.Noeuds[i]-1)]=Maill.Coord[int(3*i)]
                y[int(Maill.Noeuds[i]-1)]=Maill.Coord[int(3*i+1)]
                L=L+[Maill.Noeuds[i]]
        triang = mtri.Triangulation(x, y)
        fig = plt.figure()
        ax = fig.add_subplot(1,1,1)
        ax.triplot(triang, c="#D3D3D3", marker='.', markerfacecolor="#DC143C",
                   markeredgecolor="black", markersize=10)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        plt.show()
        fig = plt.figure()
        ax = fig.add_subplot(1,1,1, projection='3d')
        ax.plot_trisurf(triang, Ad.T[t], cmap='jet')
        ax.scatter(x,y,Ad.T[t], marker='.', s=10, c="black", alpha=0.5)
        ax.view_init(elev=60, azim=-45)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('T')
        plt.show()
    def AssemblageModePGD(self,RES):
        """
        Description
        ----------
        Cette méthode assemble les modes temporelles et spatiaux de la méthode PGD dans une matrice.

        Parameters
        ----------
        RES : Class
            Objet contenant les résultats pour la méthode PGD.

        Returns
        -------
        T : array([NnWOb,Ntemps])
            Matrice contenant les modes assemblés.
        """
        T = np.zeros([RES.NnWOb,RES.Ntemps])
        for i in range(RES.Ntemps):
            T[:,i] = RES.Rtot@RES.Stot[i,:]
        return T
    def AddBoundary(self,Tri,RES,T,Boundary = 0):
        """
        Description
        ----------
        Cette méthode ajoute les bords dans la matrice de la solution.

        Parameters
        ----------
        Tri : Class
            Objet de classe Triangles.
        RES : Class
            Objet contenant les résultats d'une méthode de calcul.
        T : array([NnWOb,Ntemps])
            Matrice des résultats du calcul (sans les bords).
        Boundary : float, optional
            Valeur sur les bords (conditions de type Dirichlet). Par défaut, c'est 0.

        Returns
        -------
        Ttot : array([Nn,Ntemps])
            Matrice des résultats du calcul (avec les bords).
        """
        Ttot = Boundary*np.ones([Tri.Nn,RES.Ntemps])
        for i in range(RES.Ntemps):
            Ttot[Tri.Nn-Tri.NnWOb:Tri.Nn,i] = T[:,i]
        return Ttot
    def SolAnalytique(self,Maill,Ntemps,Tfin):
        """
        Description
        ----------
        Calcul de la solution analytique de l'EDP.

        Parameters
        ----------
        Maill : Class
            Objet de classe Maillage.
        Ntemps : int
            Nombre de points dans la discrétisation temporelle.
        Tfin : float
            Temps final.

        Returns
        -------
        Sol : array([Nn,Ntemps])
            Matrice contenant les valeurs de la solution analytique.
        """
        if self.NameSource == "Diffusion3":
            t = [i for i in range(Ntemps)]
            t = Tfin/(Ntemps-1)*np.array(t)
            Sol = np.tensordot(np.sin(2*np.pi*(Maill.x-1))*np.sin(2*np.pi*(Maill.y-1)),np.sin(np.pi*t),axes=0)
        return Sol