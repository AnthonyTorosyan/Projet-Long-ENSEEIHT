# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 11:11:50 2023

@author: antho
"""

import numpy as np

class Triplet:
    def __init__(self):
        """
        Description
        -------
        data sera organisée de la façon suivante (pour une matrice de coefficient M_ij)
        (M_ij,(i,j)). Cette classe sera utile pour convertir les données avec Scipy (matrice creuse)

        Returns
        -------
        None.
        """
        self.data = ([],([],[]))
    def append(self,I,J,val):
        """
        Description
        ----------
        Cette fonction permet d'ajouter un nouvel élément dans data

        Parameters
        ----------
        I : int
            Correspond à la ligne de la matrice.
        J : int
            Correspond à la colonne de la matrice.
        val : float
            Valeur de la matrice ligne I, colonne J.

        Returns
        -------
        None.
        """
        self.data[0].append(val)
        self.data[1][0].append(I)
        self.data[1][1].append(J)
        
class Calcul:
    def MethodeTrapeze(self,F,dt,Ntemps):
        """
        Description
        ----------
        Calcul d'une intégrale par la méthode des trapèzes.

        Parameters
        ----------
        F : array(Ntemps)
            Vecteur contenant les valeurs de la fonction sur les Ntemps points.
        dt : float
            Le pas de temps.
        Ntemps : int
            Nombre de points pour la discrétisation en temps.

        Returns
        -------
        float
            Résultat de l'intégrale.
        """
        return dt*((F[0]+F[-1])/2+np.sum(F[1:Ntemps-1]))
    def EulerImplicite(self,F,a,b,dt,Ntemps):
        """
        Description
        ----------
        Résolution d'une équation différentielle du 1er ordre du type 
        a*y(t)+b*dt(y(t)) = f(t) par la méthode d'Euler implicite.

        Parameters
        ----------
        F : array(Ntemps)
            Vecteur contenant les valeurs de f(t).
        a : float
            Coefficient devant y(t).
        b : float
            Coefficient devant dt(y(t)).
        dt : float
            Le pas de temps.
        Ntemps : int
            Nombre de points pour la discrétisation en temps.

        Returns
        -------
        Y : array(Ntemps)
            Vecteur contenant les valeurs de y(t).
        """
        Y = np.zeros(Ntemps)
        for i in range(Ntemps-1):
            Y[i+1] = 1/(a+b/dt)*(F[i+1]+b/dt*Y[i])
        return Y

class Coefficient(Calcul):
    def __init__(self,Ntemps,dt,NnWOb,Mode):
        """
        Description
        ----------
        Cette classe permettra de calculer les divers coefficients (AR,BR,CS,AS,BS,CR) 
        nécessaire à la méthode PGD.

        Parameters
        ----------
        Ntemps : int
            Nombre de points pour la discrétisation en temps.
        dt : float
            Le pas de temps.
        NnWOb : int
            Nombre de noeuds à l'intérieur du maillage (sans les bords).
        Mode : int
            Nombre de modes à calculer.

        Returns
        -------
        None.
        """
        self.Ntemps = Ntemps
        self.dt = dt
        self.NnWOb = NnWOb
        self.Mode = Mode
    def CR(self,Source,S,Stot,Rtot,M,K,C1,C2):
        """
        Description
        ----------
        Algorithme de calcul du coefficient CR

        Parameters
        ----------
        Source : array([NnWOb,Ntemps])
            Source de l'EDP.
        S : array(Ntemps)
            S_m(t) à l'itération Iter-1.
        Stot : array([Ntemps,Mode])
            Matrice de la partie temporelle des modes.
        Rtot : array([NnWOb,Mode])
            Matrice de la partie spatiale des modes.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        array(NnWOb)
            Vecteur contenant les valeurs de CR sur le maillage.
        """
        CR1 = np.zeros(self.NnWOb)
        for i in range(self.NnWOb):
            CR1[i] = Coefficient.MethodeTrapeze(self,Source[i,:]*S,self.dt,self.Ntemps)
        IntTot2 = np.zeros(self.Mode)
        IntTot3 = np.zeros(self.Mode)
        for i in range(self.Mode):
            IntTot2[i] = Coefficient.MethodeTrapeze(self,np.gradient(Stot[:,i])*S,self.dt,self.Ntemps)
            IntTot3[i] = Coefficient.MethodeTrapeze(self,Stot[:,i]*S,self.dt,self.Ntemps)
        CR2 = Rtot@IntTot2
        CR3 = Rtot@IntTot3
        return M@(CR1-C1*CR2)-C2*K@CR3
    def CS(self,Source,R,Stot,Rtot,M,K,C1,C2):
        """
        Description
        ----------
        Algorithme de calcul du coefficient CS

        Parameters
        ----------
        Source : array([NnWOb,Ntemps])
            Source de l'EDP.
        R : array(NnWOb)
            R_m(x) à l'itération Iter..
        Stot : array([Ntemps,Mode])
            Matrice de la partie temporelle des modes.
        Rtot : array([NnWOb,Mode])
            Matrice de la partie spatiale des modes.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        array(Ntemps)
            Vecteur contenant les valeurs de CR sur la discrétisation temporelle.
        """
        CS1 = np.zeros(self.Ntemps)
        for i in range(self.Ntemps):
            CS1[i] = Source[:,i]@M@R
        VectInt2 = np.zeros(self.Mode)
        VectInt3 = np.zeros(self.Mode)
        dStot = np.zeros([self.Ntemps,self.Mode])
        for i in range(self.Mode):
            Rmode = Rtot[:,i]
            VectInt2[i] = Rmode@M@R
            dStot[:,i] = np.gradient(Stot[:,i])
            VectInt3[i] = Rmode@K@R
        CS2 = dStot@VectInt2
        CS3 = Stot@VectInt3
        return CS1-C1*CS2-C2*CS3
        