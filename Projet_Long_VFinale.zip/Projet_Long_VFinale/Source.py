# -*- coding: utf-8 -*-
"""
Created on Thu Feb 16 11:22:42 2023

@author: antho
"""

import numpy as np

class Source:
    def Crop(self,SourceMatrix,Triangles):
        """
        Description
        ----------
        Cette fonction permet d'enlever les bords dans le vecteur Source

        Parameters
        ----------
        SourceMatrix : array([NnWOb,Ntemps])
            Matrice contenant toutes les valeurs de la source.
        Triangles : Class
            Classe contenant les informations sur les triangles du maillage.

        Returns
        -------
        array([Nn-NnWOb,Ntemps])
            Matrice des valeurs de la source sans les bords.
        """
        return SourceMatrix[Triangles.Nn-Triangles.NnWOb:Triangles.Nn,:] 
        
class constante(Source):
    def __init__(self,Amp,Maill,Ntemps):
        """
        Description
        ----------
        Permet d'obtenir une source constante.

        Parameters
        ----------
        Amp : float
            Amplitude de la source.
        Maill : Class
            Objet de classe Maillage.
        Ntemps : int
            Nombre de points dans la discrétisation en temps.

        Returns
        -------
        None.
        """
        self.NameSource = "Constante"
        self.val = Amp*np.ones([Maill.Nn,Ntemps])
    def getval(self):
        return self.val 
       
class diffusion1(Source):
    def __init__(self,Maill,Tfin,Ntemps):
        """
        Description
        ----------
        Calcul de la source 1+2*x*t.

        Parameters
        ----------
        Maill : Class
            Objet de classe Maillage.
        Tfin : float
            Temps final.
        Ntemps : int
            Nombre de points dans la discrétisation en temps.

        Returns
        -------
        None.
        """
        self.NameSource = "Diffusion1"
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        self.val = 1.0+2*np.tensordot(X,t,axes=0)
    def getval(self):
        return self.val

class diffusion2(Source):
    def __init__(self,Maill,Tfin,Ntemps,C1,C2):
        """
        Description
        ----------
        Calcul de la source pi*sin(pi/L*(x-L))*sin(pi/L*(y-L))*(C1*cos(pi*t)+2*C2*pi/L*sin(pi*t))

        Parameters
        ----------
        Maill : Class
            Onjet de classe Maillage.
        Tfin : float
            Temps final.
        Ntemps : int
            Nombre de points dans la discrétisation en temps.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        None.
        """
        self.NameSource = "Diffusion2"
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        Y = Maill.y
        L = np.max(Maill.Coord)
        self.val = np.pi*np.tensordot(np.sin(2*np.pi/L*(X-L))*np.sin(2*np.pi/L*(Y-L)),C1*np.cos(np.pi*t)+8*C2*np.pi/L/L*np.sin(np.pi*t),axes=0)
        
class diffusion3(Source):
    def __init__(self,M,Maill,Tfin,Ntemps,C1,C2):
        """
        Description
        ----------
        Calcul de la source liée à la solution analytique Diffusion3. Cela crée
        une source contenant un nombre de modes fixé par l'utilisateur.

        Parameters
        ----------
        M : int
            Nombre de modes pour la source Diffusion3.
        Maill : Class
            Objet de classe Maillage.
        Tfin : float
            Temps final.
        Ntemps : int
            Nombre de points dans la discrétisation temporelle.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        None.

        """
        self.NameSource = "Diffusion3"
        Nn = int(np.max(Maill.Noeuds))
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        Y = Maill.y
        self.val = np.zeros([Nn,Ntemps])
        for m in range(M):
            dt = np.tensordot(np.sin(2*np.pi*(X-1))*np.sin(2*np.pi*(Y-1))*np.cos(2*np.pi*m/M*X)*np.cos(2*np.pi*m/M*Y),np.pi*np.cos(np.pi*t)*np.cos(2*np.pi*m/M*t)-2*np.pi*m/M*np.sin(np.pi*t)*np.sin(2*np.pi*m/M*t),axes=0)
            dx1 = np.tensordot(np.sin(2*np.pi*(Y-1))*np.cos(2*np.pi*m/M*Y)*(-4*np.pi**2*(np.sin(2*np.pi*(X-1))*np.cos(2*np.pi*m/M*X)+m/M*np.sin(2*np.pi*m/M*X)*np.cos(2*np.pi*(X-1)))),np.sin(np.pi*t)*np.cos(2*np.pi*m/M*t),axes=0)
            dy1 = np.tensordot(np.sin(2*np.pi*(X-1))*np.cos(2*np.pi*m/M*X)*(-4*np.pi**2*(np.sin(2*np.pi*(Y-1))*np.cos(2*np.pi*m/M*Y)+m/M*np.sin(2*np.pi*m/M*Y)*np.cos(2*np.pi*(Y-1)))),np.sin(np.pi*t)*np.cos(2*np.pi*m/M*t),axes=0)
            dx2 = np.tensordot(np.sin(2*np.pi*(Y-1))*np.cos(2*np.pi*m/M*Y)*(-4*m/M*np.pi**2*(m/M*np.cos(2*np.pi*m/M*X)*np.sin(2*np.pi*(X-1))+np.cos(2*np.pi*(X-1))*np.sin(2*np.pi*m/M*X))),np.sin(np.pi*t)*np.cos(2*np.pi*m/M*t),axes=0)
            dy2 = np.tensordot(np.sin(2*np.pi*(X-1))*np.cos(2*np.pi*m/M*X)*(-4*m/M*np.pi**2*(m/M*np.cos(2*np.pi*m/M*Y)*np.sin(2*np.pi*(Y-1))+np.cos(2*np.pi*(Y-1))*np.sin(2*np.pi*m/M*Y))),np.sin(np.pi*t)*np.cos(2*np.pi*m/M*t),axes=0)
            self.val = self.val+C1*dt-C2*(dx1+dx2+dy1+dy2)
            
class NonLinéairePGD(Source):
    def __init__(self,Equ,Maill,Tfin,Ntemps):
        """
        Description
        ----------
        Source pour le prolème PGD non linéaire. Problème de la forme
        dt(u)-div(exp(beta*u)grad(u)) = Source(x,t) si "NonLinéairePGDexp"
        ou dt(u)-div((a*u^2+b*u+c)grad(u)) = Source(x,t) si "NonLinéairePGDquadratique"
        Avec u = x(1-x)y(1-y)t

        Parameters
        ----------
        Equ : Class
            Objet de classe EDPsca.
        Maill : Class
            Objet de classe Mesh.
        Tfin : float
            Temps final.
        Ntemps : int
            Nombre de points dans la discrétisation temporelle.

        Returns
        -------
        None.
        """
        self.NameSource = Equ.NLineaire
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        Y = Maill.y
        if self.NameSource == "NonLinéairePGDexp":
            dt = np.tensordot(X*(1-X)*Y*(1-Y),np.ones(Ntemps),axes=0)
            exp = np.exp(Equ.beta*np.tensordot(X*(1-X)*Y*(1-Y),t,axes=0))
            dx = np.multiply(np.tensordot(Y*(1-Y),t,axes=0),np.tensordot(Equ.beta*Y*(1-Y)*(1-2*X)**2,t,axes=0)-2)
            dy = np.multiply(np.tensordot(X*(1-X),t,axes=0),np.tensordot(Equ.beta*X*(1-X)*(1-2*Y)**2,t,axes=0)-2)
            self.val = dt-exp*(dx+dy)
        elif self.NameSource == "NonLinéairePGDquadratique":
            dt = np.tensordot(X*(1-X)*Y*(1-Y),np.ones(Ntemps),axes=0)
            dx1 = (2*Equ.a*np.tensordot(X*(1-X)*Y*(1-Y),t,axes=0)+Equ.b)*np.tensordot((Y*(1-Y))**2*(1-2*X)+(X*(1-X))**2*(1-2*Y),t**2,axes=0)
            dx2 = 2*np.tensordot(Y*(1-Y)+X*(1-X),t,axes=0)
            self.val = dt-(dx1-dx2)