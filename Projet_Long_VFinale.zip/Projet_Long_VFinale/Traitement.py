# -*- coding: utf-8 -*-
"""
Created on Sun Feb 19 21:52:47 2023

@author: antho
"""

import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
from numpy.linalg import norm

class PostTraitement:
    def __init__(self,NameSource,Modes):
        """
        Description
        ----------
        Cette classe est consacrée au post-traitement.

        Parameters
        ----------
        NameSource : Chaîne de caractères
            Nom de la source utilisée.
        Modes : Liste
            Liste contenant le nombre de modes à calculer pour chaque simulation.

        Returns
        -------
        None.
        """
        self.methode = "PGD"
        self.NameSource = NameSource
        self.Modes = Modes
        self.NbrSimu = len(Modes)
        self.Rtot = []
        self.Stot = []
        self.TtotWOb = []
        self.Ttot = []
        self.Sol = ()
        self.Err = []
        self.TpsCalcul = []
    def RecupInfoPGD(self,RES):
        self.Rtot.append(RES.Rtot)
        self.Stot.append(RES.Stot)
        self.TpsCalcul.append(RES.TpsCalcul)
    def result_plot(self,Ad,Maill,t):
        """
        Description
        ----------
        Méthode permettant de tracer les graphes.

        Parameters
        ----------
        Ad : array([Nn,Ntemps])
            Matrice de la solution calculée.
        Maill : Class
            Objet de classe Maillage.
        t : int
            Itération temporelle affichée par le graphe.

        Returns
        -------
        None.
        """
        triang = mtri.Triangulation(Maill.x, Maill.y)
        fig = plt.figure()
        ax = fig.add_subplot(1,1,1, projection='3d')
        ax.plot_trisurf(triang, Ad.T[t], cmap='jet')
        ax.scatter(Maill.x,Maill.y,Ad.T[t], marker='.', s=10, c="black", alpha=0.5)
        ax.view_init(elev=60, azim=-45)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('T')
        plt.show()
    def solution_plot(self,Ad,Maill,Ntemps,mode):
        """
        Description
        ----------
        Méthode permettant de tracer les graphes de la solution dans une seule
        figure
        Parameters
        ----------
        Ad : array([Nn,Ntemps])
        Matrice de la solution calculée.
        Maill : Class
        Objet de classe Maillage.
        Ntemps: integer 
        Nombre de pas de temps
        mode : integer
        nombre de mode
        Returns
        -------
        None.
        """        
        triang = mtri.Triangulation(Maill.x, Maill.y)
        fig = plt.figure(figsize=np.array([15,10]))
        ttl="Solution avec {0} pour la source {1}, un maillage de {2} noeuds et {3} modes".format(self.methode,self.NameSource,np.shape(Ad)[0],mode)
        fig.suptitle(ttl)
        for i in range(5):
            
            ax = fig.add_subplot(2, 3, i+1, projection='3d')
            ax.plot_trisurf(triang, Ad.T[int(i*Ntemps/5)], cmap='jet')
            ax.scatter(Maill.x,Maill.y,Ad.T[int(i*Ntemps/5)], marker='.', s=10, c="black", alpha=0.5)
            ax.view_init(elev=60, azim=-45)
            ax.set_xlabel('X')
            ax.set_ylabel('Y')
            ax.set_zlabel('T')
            ax.set_title("Solution à t=i*T/5 pour i={0}".format(i))

        ax = fig.add_subplot(2, 3, 6, projection='3d')
        ax.plot_trisurf(triang, Ad.T[-1], cmap='jet')
        ax.scatter(Maill.x,Maill.y,Ad.T[-1], marker='.', s=10, c="black", alpha=0.5)
        ax.view_init(elev=60, azim=-45)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('T')
        ax.set_title("Solution à t=i*T/5 pour i=5") 
        
        plt.show()    
    def Analy_plot(self,Ad,Maill,Ntemps):
        """
        Description
        ----------
        Méthode permettant de tracer les graphes de la sol analytique dans une 
        seule figure
        Parameters
        ----------
        Ad : array([Nn,Ntemps])
        Matrice de la solution calculée.
        Maill : Class
        Objet de classe Maillage.
        Ntemps : integer
        nombre de pas de temps
        Returns
        -------
        None.
        """        
        triang = mtri.Triangulation(Maill.x, Maill.y)
        fig = plt.figure(figsize=np.array([15,10]))
        ttl="Solution analytique pour la source {0}, un maillage de {1} noeuds".format(self.NameSource,np.shape(Ad)[0])
        fig.suptitle(ttl)
        for i in range(5):
            
            ax = fig.add_subplot(2, 3, i+1, projection='3d')
            ax.plot_trisurf(triang, Ad.T[int(i*Ntemps/5)], cmap='jet')
            ax.scatter(Maill.x,Maill.y,Ad.T[int(i*Ntemps/5)], marker='.', s=10, c="black", alpha=0.5)
            ax.view_init(elev=60, azim=-45)
            ax.set_xlabel('X')
            ax.set_ylabel('Y')
            ax.set_zlabel('T')
            ax.set_title("Solution à t=i*T/5 pour i={0}".format(i))

        ax = fig.add_subplot(2, 3, 6, projection='3d')
        ax.plot_trisurf(triang, Ad.T[-1], cmap='jet')
        ax.scatter(Maill.x,Maill.y,Ad.T[-1], marker='.', s=10, c="black", alpha=0.5)
        ax.view_init(elev=60, azim=-45)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('T')
        ax.set_title("Solution à t=i*T/5 pour i=5") 
        
        plt.show()           
    def AssemblageModePGD(self):
        """
        Description
        ----------
        Cette méthode assemble les modes temporelles et spatiaux de la méthode PGD dans une matrice.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            Rtot_i = self.Rtot[i]
            Stot_i = self.Stot[i]
            NnWOb = np.shape(Rtot_i)[0]
            Ntemps = np.shape(Stot_i)[0]
            T = np.zeros([NnWOb,Ntemps])
            for j in range(Ntemps):
                T[:,j] = Rtot_i@Stot_i[j,:]
            self.TtotWOb.append(T)
    def AddBoundary(self,Tri,Boundary = 0):
        """
        Description
        ----------
        Cette méthode ajoute les bords dans la matrice de la solution.

        Parameters
        ----------
        Tri : Class
            Objet de classe Triangles.
        Boundary : float, optional
            Valeur sur les bords (conditions de type Dirichlet). Par défaut, c'est 0.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            T = self.TtotWOb[i]
            Ntemps = np.shape(T)[1]
            Twb = Boundary*np.ones([Tri.Nn,Ntemps])
            for j in range(Ntemps):
                Twb[Tri.Nn-Tri.NnWOb:Tri.Nn,j] = T[:,j]
            self.Ttot.append(Twb)
    def SolAnalytique(self,M,Maill,Ntemps,Tfin):
        """
        Description
        ----------
        Calcul de la solution analytique de l'EDP.

        Parameters
        ----------
        M : int
            Nombre de modes pour la solution Diffusion3.
        Maill : Class
            Objet de classe Maillage.
        Ntemps : int
            Nombre de points dans la discrétisation temporelle.
        Tfin : float
            Temps final.

        Returns
        -------
        None.
        """
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        Y = Maill.y
        if self.NameSource == "Diffusion2":
            self.Sol = (np.tensordot(np.sin(2*np.pi*(X-1))*np.sin(2*np.pi*(Y-1)),np.sin(np.pi*t),axes=0))
        if self.NameSource == "Diffusion3":
            Nn = int(np.max(Maill.Noeuds))
            self.Sol = np.zeros([Nn,Ntemps])
            for m in range(M):
                self.Sol = self.Sol+np.tensordot(np.sin(2*np.pi*(X-1))*np.sin(2*np.pi*(Y-1))*np.cos(2*np.pi*m/M*X)*np.cos(2*np.pi*m/M*Y),np.sin(np.pi*t)*np.cos(2*np.pi*m/M*t),axes=0)
        if self.NameSource == "NonLinéairePGDexp" or self.NameSource == "NonLinéairePGDquadratique":
            self.Sol = np.tensordot(X*(1-X)*Y*(1-Y),t,axes=0)
    def Erreur(self):
        """
        Description
        ----------
        Cette méthode permet de calculer l'erreur relative entre les solutions 
        calculée et analytique pour chaque pas de temps.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            Err_i = []
            Ttot_i = self.Ttot[i]
            Ntemps = np.shape(Ttot_i)[1]
            for j in range(Ntemps):
                Err_i.append(norm(Ttot_i[:,j]-self.Sol[:,j],2)/(1+norm(self.Sol[:,j],2)))
            self.Err.append(Err_i)
    def Affichage(self,Maill,Tfin,Ntemps):
        """
        Description
        ----------
        Affichage du temps de calcul, et des informations sur la norme relative pour chaque simulation.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            print('----------------------------------------------------',end='\n')
            print('------------- NOMBRE DE MODES: '+str(self.Modes[i])+' -------------------',end='\n')
            print('----------------------------------------------------',end='\n \n')
            print('Temps de calcul', self.TpsCalcul[i],end='\n \n')
            print("Minimum de l'erreur relative",np.min(self.Err[i][1:]),end='\n')
            print("Moyenne de l'erreur relative",np.mean(self.Err[i]),end='\n')
            print("Maximum de l'erreur relative",np.max(self.Err[i]),end='\n \n')
        if self.NbrSimu == 1:
            t = [i for i in range(Ntemps)]
            t = Tfin/(Ntemps-1)*np.array(t)
            triang = mtri.Triangulation(Maill.x, Maill.y)
            # Affichage des modes temporels
            fig,ax = plt.subplots()
            for i in range(self.Modes[0]):
                ax.plot(t,self.Stot[0][:,i],label="Mode temporel n°"+str(i+1))
            ax.set_xlabel("t")
            ax.set_ylabel("Amplitudes des modes temporels")
            ax.legend()
            plt.grid()
            plt.show()
            # Affichage des modes spatiaux
            Nn = int(np.max(Maill.Noeuds))
            NnWOb = np.size(Maill.NoeudsNotBoundary)
            RtotWb = np.zeros([Nn,self.Modes[0]])
            for i in range(self.Modes[0]):
                RtotWb[Nn-NnWOb:Nn,i] = self.Rtot[0][:,i]
            if self.Modes[0] > 1:
                fig, ax = plt.subplots(1,self.Modes[0],figsize=(10,5),subplot_kw={'projection': '3d'})
                for i in range(self.Modes[0]):
                    ax[i].plot_trisurf(triang,RtotWb[:,i],cmap='jet')
                    ax[i].set_xlabel('X')
                    ax[i].set_ylabel('Y')
                    ax[i].set_zlabel('Amplitude')
                    ax[i].set_title("Mode spatial n°"+str(i+1))
                plt.show()
            elif self.Modes[0] == 1:
                fig, ax = plt.subplots(1,1,figsize=(10,5),subplot_kw={'projection': '3d'})
                ax.plot_trisurf(triang,RtotWb[:,i],cmap='jet')
                ax.set_xlabel('X')
                ax.set_ylabel('Y')
                ax.set_zlabel('Amplitude')
                ax.set_title("Mode spatial n°"+str(i+1))
                plt.show()
        elif self.NbrSimu > 1:
            MeanErr = np.zeros(self.NbrSimu)
            for i in range(self.NbrSimu):
                MeanErr[i] = np.mean(self.Err[i][:])
            fig,ax = plt.subplots()
            ax.plot(self.Modes,MeanErr,"k:o")
            ax.set_xlabel("Nombre de modes calculés")
            ax.set_ylabel("Erreur")
            ax.set_title("Erreur en fonction du nombre de modes calculés")
            plt.grid()
            plt.show()
class PostTraitement_POD:
    def __init__(self,NameSource,Snapshots):
        """
        Description
        ----------
        Cette classe est consacrée au post-traitement de la méthode POD.
        Parameters
        ----------
        NameSource : Chaîne de caractères
        Nom de la source utilisée.
        Modes : Liste
        Liste contenant le nombre de Snapshots utilisé pour chaque simulation.
        Returns
        -------
        None.
        """
        self.methode="POD"
        self.NameSource = NameSource
        self.Snapshots = Snapshots
        self.NbrSimu = len(Snapshots)
        self.SolWOb = []
        self.Sol = []
        self.SolAnaly = []
        self.Err = []
        self.TpsCalcul = []
        self.InfoReduc = []
    def RecupInfoPOD(self,RES):
        self.SolWOb.append(RES.sol)
        self.TpsCalcul.append(RES.TpsCalcul)
        self.InfoReduc.append(RES.TailleReduc)
    def result_plot(self,Ad,Maill,t):
        """
        Description
        ----------
        Méthode permettant de tracer les graphes.
        Parameters
        ----------
        Ad : array([Nn,Ntemps])
        Matrice de la solution calculée.
        Maill : Class
        Objet de classe Maillage.
        t : int
        Itération temporelle affichée par le graphe.
        Returns
        -------
        None.
        """
        triang = mtri.Triangulation(Maill.x, Maill.y)
        fig = plt.figure()
        ax = fig.add_subplot(1,1,1, projection='3d')
        ax.plot_trisurf(triang, Ad.T[t], cmap='jet')
        ax.scatter(Maill.x,Maill.y,Ad.T[t], marker='.', s=10, c="black", alpha=0.5)
        ax.view_init(elev=60, azim=-45)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('T')
        plt.show()
    def solution_plot(self,Ad,Maill,Ntemps,snaps):
        """
        Description
        ----------
        Méthode permettant de tracer les graphes de la solution dans une seule 
        figure.
        Parameters
        ----------
        Ad : array([Nn,Ntemps])
        Matrice de la solution calculée.
        Maill : Class
        Objet de classe Maillage.
        Ntemps : integer 
        Nombre de pas de temps
        snaps: integer 
        nombre de snapshots
        Returns
        -------
        None.
        """        
        triang = mtri.Triangulation(Maill.x, Maill.y)
        fig = plt.figure(figsize=np.array([15,10]))
        ttl="Solution avec {0} pour la source {1}, un maillage de {2} noeuds et {3} de snapshots".format(self.methode,self.NameSource,np.shape(Ad)[0],snaps)
        fig.suptitle(ttl)
        for i in range(5):
            
            ax = fig.add_subplot(2, 3, i+1, projection='3d')
            ax.plot_trisurf(triang, Ad.T[int(i*Ntemps/5)], cmap='jet')
            ax.scatter(Maill.x,Maill.y,Ad.T[int(i*Ntemps/5)], marker='.', s=10, c="black", alpha=0.5)
            ax.view_init(elev=60, azim=-45)
            ax.set_xlabel('X')
            ax.set_ylabel('Y')
            ax.set_zlabel('T')
            ax.set_title("Solution à t=i*T/5 pour i={0}".format(i))

        ax = fig.add_subplot(2, 3, 6, projection='3d')
        ax.plot_trisurf(triang, Ad.T[-1], cmap='jet')
        ax.scatter(Maill.x,Maill.y,Ad.T[-1], marker='.', s=10, c="black", alpha=0.5)
        ax.view_init(elev=60, azim=-45)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('T')
        ax.set_title("Solution à t=i*T/5 pour i=5") 
        
        plt.show()    
    def Analy_plot(self,Ad,Maill,Ntemps):
        """
        Description
        ----------
        Méthode permettant de tracer les graphes de la solution analytique dans 
        une seule figure.
        Parameters
        ----------
        Ad : array([Nn,Ntemps])
        Matrice de la solution calculée.
        Maill : Class
        Objet de classe Maillage.
        Ntemps : integer
        nombre de pas de temps
        Returns
        -------
        None.
        """        
        triang = mtri.Triangulation(Maill.x, Maill.y)
        fig = plt.figure(figsize=np.array([15,10]))
        ttl="Solution analytique pour la source {0}, un maillage de {1} noeuds".format(self.NameSource,np.shape(Ad)[0])
        fig.suptitle(ttl)
        for i in range(5):
            
            ax = fig.add_subplot(2, 3, i+1, projection='3d')
            ax.plot_trisurf(triang, Ad.T[int(i*Ntemps/5)], cmap='jet')
            ax.scatter(Maill.x,Maill.y,Ad.T[int(i*Ntemps/5)], marker='.', s=10, c="black", alpha=0.5)
            ax.view_init(elev=60, azim=-45)
            ax.set_xlabel('X')
            ax.set_ylabel('Y')
            ax.set_zlabel('T')
            ax.set_title("Solution à t=i*T/5 pour i={0}".format(i))

        ax = fig.add_subplot(2, 3, 6, projection='3d')
        ax.plot_trisurf(triang, Ad.T[-1], cmap='jet')
        ax.scatter(Maill.x,Maill.y,Ad.T[-1], marker='.', s=10, c="black", alpha=0.5)
        ax.view_init(elev=60, azim=-45)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('T')
        ax.set_title("Solution à t=i*T/5 pour i=5") 
        
        plt.show()            
    def AddBoundary(self,Tri,Boundary = 0):
        """
        Description
        ----------
        Cette méthode ajoute les bords dans la matrice de la solution.

        Parameters
        ----------
        Tri : Class
        Objet de classe Triangles.
        Boundary : float, optional
        Valeur sur les bords (conditions de type Dirichlet). Par défaut, c'est 0.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            T = self.SolWOb[i]
            Ntemps = np.shape(T)[1]
            Twb = Boundary*np.ones([Tri.Nn,Ntemps])
            for j in range(Ntemps):
                Twb[Tri.Nn-Tri.NnWOb:Tri.Nn,j] = T[:,j]
            self.Sol.append(Twb)
    def SolAnalytique(self,M,Maill,Ntemps,Tfin):
        """
        Description
        ----------
        Calcul de la solution analytique de l'EDP.

        Parameters
        ----------
        M : int
        Nombre de modes pour la solution Diffusion3.
        Maill : Class
        Objet de classe Maillage.
        Ntemps : int
        Nombre de points dans la discrétisation temporelle.
        Tfin : float
        Temps final.

        Returns
        -------
        None.
        """
        t = [i for i in range(Ntemps)]
        t = Tfin/(Ntemps-1)*np.array(t)
        X = Maill.x
        Y = Maill.y
        if self.NameSource == "Diffusion2":
            self.SolAnaly = (np.tensordot(np.sin(2*np.pi*(X-1))*np.sin(2*np.pi*(Y-1)),np.sin(np.pi*t),axes=0))
        if self.NameSource == "Diffusion3":
            Nn = int(np.max(Maill.Noeuds))
            self.SolAnaly = np.zeros([Nn,Ntemps])
            for m in range(M):
                self.SolAnaly = self.Sol+np.tensordot(np.sin(2*np.pi*(X-1))*np.sin(2*np.pi*(Y-1))*np.cos(2*np.pi*m/M*X)*np.cos(2*np.pi*m/M*Y),np.sin(np.pi*t)*np.cos(2*np.pi*m/M*t),axes=0)
        if self.NameSource == "NonLinéairePGDexp" or self.NameSource == "NonLinéairePGDquadratique":
            self.Sol = np.tensordot(X*(1-X)*Y*(1-Y),t,axes=0)  
    def Erreur(self):
        """
        Description
        ----------
        Cette méthode permet de calculer l'erreur relative entre les solutions 
        calculée et analytique pour chaque pas de temps.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            Err_i = []
            Ttot_i = self.Sol[i]
            Ntemps = np.shape(Ttot_i)[1]
            for j in range(Ntemps):
                Err_i.append(norm(Ttot_i[:,j]-self.SolAnaly[:,j],2)/(1+norm(self.SolAnaly[:,j],2)))
            self.Err.append(Err_i)
    def Affichage(self,Maill,Tfin,Ntemps):
        """
        Description
        ----------
        Affichage du temps de calcul, et des informations sur l'erreur relative pour chaque simulation.

        Returns
        -------
        None.
        """
        for i in range(self.NbrSimu):
            print('----------------------------------------------------',end='\n')
            print('------------- NOMBRE DE SNAPSHOTS: '+str(self.Snapshots[i])+' -------------------',end='\n')
            print('----------------------------------------------------',end='\n \n')
            print('Temps de calcul', self.TpsCalcul[i],end='\n \n')
            print('La taille du problème initial est:',self.InfoReduc[i][0],end='\n \n')
            print('La taille du problème réduit est:',self.InfoReduc[i][1],end='\n \n')
            print("Minimum de l'erreur relative",np.min(self.Err[i][1:]),end='\n')
            print("Moyenne de l'erreur relative",np.mean(self.Err[i]),end='\n')
            print("Maximum de l'erreur relative",np.max(self.Err[i]),end='\n \n')
        if self.NbrSimu > 1:
            MeanErr = np.zeros(self.NbrSimu)
            for i in range(self.NbrSimu):
                MeanErr[i] = np.mean(self.Err[i][:])
            fig,ax = plt.subplots()
            ax.plot(self.Snapshots,MeanErr,"k:o")
            ax.set_xlabel("Nombre de Snapshots")
            ax.set_ylabel("Erreur relative moyenne")
            ax.set_title("Erreur en fonction du nombre de Snapshots")
            plt.grid()
            plt.show()            