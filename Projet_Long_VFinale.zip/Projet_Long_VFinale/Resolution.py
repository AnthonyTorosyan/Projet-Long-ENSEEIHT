# -*- coding: utf-8 -*-
"""
Created on Thu Feb 16 19:05:47 2023

@author: antho
"""

from Utile import Triplet,Coefficient
import numpy as np
from numpy.linalg import norm,inv
from scipy.sparse.linalg import spsolve
from scipy.sparse import coo_matrix
from scipy.linalg import svd
from time import process_time
        
class PGD:
    def __init__(self,NnWOb,Tfin,Ntemps,Mode,MaxIter,Tol):
        """
        Description
        ----------
        Classe permettant d'utiliser la méthode Proper Generalized Decomposition.
        
        Parameters
        ----------
        NnWOb : int
            Nombre de noeuds à l'intérieur du maillage.
        Tfin : float
            Temps final du calcul.
        Ntemps : int
            Nombre de points en temps.
        Mode : int
            Nombre de modes à calculer.
        MaxIter : int
            Maximum d'itérations pour la recherche des modes.
        Tol : float
            Tolérance pour la convergence des modes.

        Returns
        -------
        None.
        """
        self.NnWOb = NnWOb
        self.Tfin = Tfin
        self.Ntemps = Ntemps
        self.dt = self.Tfin/float(self.Ntemps-1)
        self.Mode = Mode
        self.MaxIter = MaxIter
        self.Tol = Tol
        self.Coeff = Coefficient(self.Ntemps,self.dt,self.NnWOb,self.Mode)
        self.Stot = np.zeros([self.Ntemps,self.Mode])
        self.Rtot = np.zeros([self.NnWOb,self.Mode])
        self.TpsCalcul = 0
    def CalculSm(self,R,Source,K,M,C1,C2,NameSource="",MNL=0):
        """
        Description
        ----------
        Calcul de S_m(t) à l'itération Iter.

        Parameters
        ----------
        R : array(NnWOb)
            R_m(x) à l'itération Iter.
        Source : array([NnWOb,Ntemps])
            Source de l'EDP.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.
        NameSource : Chaîne de caractère, optional
            Ceci sert à repérer si nous sommes dans le cas non linéaire. La valeur par défaut est "".
        MNL : array([NnWOb,Ntemps]), optional
            Matrice liée au terme non linéaire. La valeur par défaut est 0.

        Returns
        -------
        S : array(Ntemps)
            S_m(t) à l'itération Iter.
        """
        # Calcul des coefficients
        AR = C2*R@K@R
        BR = C1*R@M@R
        # Calcul du second membre
        CS = self.Coeff.CS(Source,R,self.Stot,self.Rtot,M,K,C1,C2)
        if "NonLinéaire" in NameSource:
            CS = CS-np.transpose(MNL)@R
        # Schéma d'Euler implicite
        S = self.Coeff.EulerImplicite(CS,AR,BR,self.dt,self.Ntemps)
        # Quelques affichages
        print("AR",AR)
        print("BR",BR)
        print("CS",norm(CS,2))
        print("norme S",norm(S,2),end="\n \n") 
        return S
    def CalculRm(self,S,Source,K,M,C1,C2,NameSource="",MNL=0):
        """
        Description
        ----------
        Calcul de R_m(x) à l'itération Iter.

        Parameters
        ----------
        S : array(Ntemps)
            S_m(t) à l'itération Iter-1.
        Source : array([NnWOb,Ntemps])
            Source de l'EDP.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.
        NameSource : Chaîne de caractère, optional
            Ceci sert à repérer si nous sommes dans le cas non linéaire. La valeur par défaut est "".
        MNL : array([NnWOb,Ntemps]), optional
            Matrice liée au terme non linéaire. La valeur par défaut est 0.

        Returns
        -------
        R : array(NnWOb)
            R_m(x) à l'itération Iter.
        """
        # Calcul des coefficients
        AS = self.Coeff.MethodeTrapeze(S**2,self.dt,self.Ntemps)
        BS = self.Coeff.MethodeTrapeze(np.gradient(S)*S,self.dt,self.Ntemps)
        # Calcul du second membre
        CR = self.Coeff.CR(Source,S,self.Stot,self.Rtot,M,K,C1,C2)
        if "NonLinéaire" in NameSource:
            CRnl = np.zeros(self.NnWOb)
            for i in range(self.NnWOb):
                CRnl[i] = self.Coeff.MethodeTrapeze(MNL[i,:]*S,self.dt,self.Ntemps)
            CR = CR-CRnl
        # Résolution du système linéaire
        R = spsolve(C2*AS*K+C1*BS*M,CR)
        # Quelques affichages
        print("AS",AS)
        print("BS",BS)
        print("CR",norm(CR,2))
        print("norme R",norm(R,2),end="\n \n")
        return R
    def DEIM(self,Triangles,PreCalcul,Ndeim,Utot,C2,Equ):
        """
        Description
        ----------
        Méthode implémentant la Discrete Empirical Interpolation Method (DEIM).
        Pour le cas non linéaire.

        Parameters
        ----------
        Triangles : Class
            Objet de classe Triangles contenant les informations des triangles.
        PreCalcul : Liste
            Liste de Tuples contenant le précalcul de différents éléments des Triangles.
        Ndeim : int
            Entier indiquant les Ndeim premiers pas de temps à construire pour le début de la DEIM.
        Utot : array([NnWOb,Ntemps])
            Matrice de la solution assemblée.
        C2 : float
            Coefficient de l'EDP devant la partie linéaire de l'opérateur spatial.
        Equ : class
            Objet de classe EDPsca.

        Returns
        -------
        MNL : array([NnWOb,Ntemps])
            Matrice du terme non linéaire.
        """
        # Reconstitution de la solution sur Ndeim pas de temps
        u = Utot[:,:Ndeim]
        # Calcul de la non linéarité
        NU = Equ.NU(Utot)-C2
        # Récupération des informations du maillage
        Tri = Triangles.Tri
        Nt = Triangles.Nt
        Nn = Triangles.Nn
        # Instanciation d'un Triplet
        t = Triplet()
        # Initialisation de la matrice non linéaire sur Ndeim éléments
        MNL = np.zeros([self.NnWOb,self.Ntemps])
        # Assemblage de la matrice non linéaire 
        for n in range(Ndeim):
            u_interm = u[:,n]
            NU_interm = np.zeros(Nn)
            NU_interm[Nn-self.NnWOb:Nn] = NU[:,n]
            for p in range(Nt):
                T = Tri[p]
                PC = PreCalcul[p]
                # Intégrale sur l'élément de référence
                IntNU = (NU_interm[int(T[0][0]-1)]+NU_interm[int(T[1][0]-1)]+NU_interm[int(T[2][0]-1)])/6
                # Matrice élémentaire
                M22 = PC[0]/2/PC[3]
                M33 = PC[1]/2/PC[3]
                M23 = PC[2]/2/PC[3]
                Melm = IntNU*np.array([[M22+M33+2*M23,-M23-M22,-M23-M33],[-M23-M22,M22,M23],[-M23-M33,M23,M33]])
                for i in range(3):
                    I = int(T[i][0]-1)
                    if Nn-self.NnWOb <= I < Nn:
                        I = I-Nn+self.NnWOb
                        for j in range(3):
                            J = int(T[j][0]-1)
                            if Nn-self.NnWOb <= J < Nn:
                                J = J-Nn+self.NnWOb
                                t.append(I,J,Melm[i,j])
            M = coo_matrix(t.data)
            # Mise à jour des coefficients de la matrice non linéaire
            MNL[:,n] = M@u_interm
        if Ndeim < self.Ntemps:
            # SVD de MNL
            V,Sgm,W = svd(MNL[:,:Ndeim])
            print(Sgm)
            # Récupération des vecteurs les plus significatifs
            i = 0
            Stop = False
            while i < self.NnWOb and Stop == False:
                if Sgm[i] >= 1e-17:
                    Nm = i+1
                    Stop == True
                i = i+1
            print("Nm =",Nm)
            # Création de P et PHI pour la projection
            P = np.eye(self.NnWOb)
            P = P[:,:Nm]
            PHI = V[:,:Nm]
            Proj = PHI@inv(np.transpose(P)@PHI)
            # Interpolation
            tt = Triplet()
            u = Utot[:Nm,Ndeim:self.Ntemps]
            for n in range(self.Ntemps-Ndeim):
                u_interm = u[:,n]
                NU_interm[Nn-self.NnWOb:Nn] = NU[:,n+Ndeim]
                for p in range(Nt):
                    T = Tri[p]
                    PC = PreCalcul[p]
                    # Intégrale de NU sur l'élément de référence
                    IntNU = (NU_interm[int(T[0][0]-1)]+NU_interm[int(T[1][0]-1)]+NU_interm[int(T[2][0]-1)])/6
                    # Matrice élémentaire
                    M22 = PC[0]/2/PC[3]
                    M33 = PC[1]/2/PC[3]
                    M23 = PC[2]/2/PC[3]
                    Melm = IntNU*np.array([[M22+M33+2*M23,-M23-M22,-M23-M33],[-M23-M22,M22,M23],[-M23-M33,M23,M33]])
                    for i in range(3):
                        I = int(T[i][0]-1)
                        if Nn-self.NnWOb <= I < Nn-self.NnWOb+Nm:
                            I = I-Nn+self.NnWOb
                            for j in range(3):
                                J = int(T[j][0]-1)
                                if Nn-self.NnWOb <= J < Nn-self.NnWOb+Nm:
                                    J = J-Nn+self.NnWOb
                                    tt.append(I,J,Melm[i,j])
                M = coo_matrix(tt.data)
                # Mise à jour des coefficients de la matrice non linéaire
                MNL[:,Ndeim+n] = Proj@M@u_interm
        print(norm(MNL,"fro"))
        return MNL
    def Calcul(self,Source,K,M,C1,C2):
        """
        Description
        ----------
        Algorithme de la méthode PGD dans le cas linéaire.

        Parameters
        ----------
        Source : array([NnWOb,Ntemps])
            Source de l'EDP.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        C1 : float
            Coefficient de l'EDP devant la dérivée temporelle.
        C2 : float
            Coefficient de l'EDP devant l'opérateur spatial.

        Returns
        -------
        None.
        """
        ti = process_time()
        for m in range(self.Mode):
            S = np.ones(self.Ntemps)
            R = np.zeros(self.NnWOb)
            Stop = False
            Iter = 0
            while (Stop == False) and (Iter <= self.MaxIter):
                Iter = Iter+1
                Rbefore = R
                Sbefore = S
                # Calcul du mode m de l'itération Iter-1 (pour le critère d'arrêt)
                M_mbefore = np.tensordot(Rbefore,Sbefore,axes=0)
                # Calcul de R_m à l'itération Iter
                R = PGD.CalculRm(self,S,Source,K,M,C1,C2)
                # Calcul de S_m à l'itération Iter
                S = PGD.CalculSm(self,R,Source,K,M,C1,C2)
                # Calcul du mode m de l'itération Iter (pour le critère d'arrêt)
                M_m = np.tensordot(R,S,axes=0)
                # Calcul de la norme du résidu pour la convergence
                NormeResidu = norm(M_m-M_mbefore,'fro')/(1+norm(M_mbefore,'fro'))
                Stop = NormeResidu <= self.Tol
                # Quelques affichages
                print("Itération",Iter)
                print("Norme Résidu",NormeResidu)
                print("Stop",Stop,end="\n \n")
            # Enregistrement du mode
            self.Stot[:,m] = S 
            self.Rtot[:,m] = R
        self.TpsCalcul = process_time()-ti
    def CalculNL(self,Ndeim,Tri,PC,Source,K,M,Equ):
        """
        Description
        ----------
        Algorithme de la méthode PGD dans le cas non linéaire.

        Parameters
        ----------
        Ndeim : Ndeim : int
            Entier indiquant les Ndeim premiers pas de temps à construire pour le début de la DEIM.
        Tri : Class
            Objet de classe Triangles contenant les informations des triangles.
        PC : Liste
            Liste de Tuples contenant le précalcul de différents éléments des Triangles.
        Source : Class
            Objet de classe source et contenant les informations de la source non linéaire.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        Equ : class
            Objet de classe EDPsca.

        Returns
        -------
        None.
        """
        C1 = Equ.C1
        C2 = Equ.NU(0)
        U = np.zeros([self.NnWOb,self.Ntemps])
        MNL = np.zeros([self.NnWOb,self.Ntemps])
        ti = process_time()
        for m in range(self.Mode):
            S = np.ones(self.Ntemps)
            R = np.zeros(self.NnWOb)
            Stop = False
            Iter = 0
            while (Stop == False) and (Iter <= self.MaxIter):
                Iter = Iter+1
                Rbefore = R
                Sbefore = S
                # Calcul du mode m de l'itération Iter-1 (pour le critère d'arrêt)
                M_mbefore = np.tensordot(Rbefore,Sbefore,axes=0)
                # Calcul de R_m à l'itération Iter
                R = PGD.CalculRm(self,S,Source.val,K,M,C1,C2,NameSource=Source.NameSource,MNL=MNL)
                # Calcul de S_m à l'itération Iter
                S = PGD.CalculSm(self,R,Source.val,K,M,C1,C2,NameSource=Source.NameSource,MNL=MNL)
                # Calcul du mode m de l'itération Iter (pour le critère d'arrêt)
                M_m = np.tensordot(R,S,axes=0)
                # Calcul de la norme du résidu pour la convergence
                NormeResidu = norm(M_m-M_mbefore,'fro')/(1+norm(M_mbefore,'fro'))
                Stop = NormeResidu <= self.Tol
                # DEIM dans le cas non linéaire
                if (Stop == False) and (Iter <= self.MaxIter):
                    MNL = PGD.DEIM(self,Tri,PC,Ndeim,U+M_m,C2,Equ)
                # Quelques affichages
                print("Itération",Iter)
                print("Norme Résidu",NormeResidu)
                print("Stop",Stop,end="\n \n")
            # Enregistrement du mode
            self.Stot[:,m] = S 
            self.Rtot[:,m] = R
            # Mise à jour de U
            U = U+M_m
        self.TpsCalcul = process_time()-ti
        
class POD:
    def __init__(self,NnWOb,Tfin,Ntemps,Snaps,Tol_proj):
        """
        Description
        ----------
        Classe permettant d'utiliser la méthode Proper ORTHOGONAL Decomposition.
        
        Parameters
        ----------
        NnWOb : int
            Nombre de noeuds à l'intérieur du maillage.
        Tfin : float
            Temps final du calcul.
        Ntemps : int
            Nombre de points en temps.
        Mode : int
            Nombre de modes à calculer.
        Snaps : int
            Le nombre de pas de temps pris en compte (snapshot) pour le calcul 
            de la solution non réduite As.
        Tol_proj : float
            Tolérance pour la prise en compte des valeurs singulières de la SVD.

        Returns
        -------
        None.
        """
        self.NnWOb = NnWOb
        self.Tfin = Tfin
        self.Ntemps = Ntemps
        self.dt = self.Tfin/float(self.Ntemps-1)
        self.Snapshot = Snaps
        self.Tol_proj = Tol_proj
        self.sol = np.zeros((self.NnWOb,self.Ntemps))
        self.TpsCalcul=0
        self.TailleReduc=[]
    def snapshot(self,K,M,F,a0,m,pas):
        """
        Description
        ----------
        Réslution du système pour les m premiers pas de temps (Snapshots) 
        
        K.Ad + M. dAd/dt = F
        
        Parameters
        ----------
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        F : array([NnWOb,Ntemps])
            Matrice telle que ces chaque colonne correspond au second membre du
            système pour un instant donné ( t(i)=i.pas pour i=0 à Ntemps-1 ).
        a0 : array([NnWOb])
            Condition initiale du schéma d'Euler.
        m : int
            le nombre de Snapshot.
        pas : float
            le pas du schéma d'Euler. pas= Tfin/(Ntemps-1)

        Returns
        -------
        As : array([NnWOb,m])
            Matrice contenant les résultats de la résolution des m premiers pas 
            de temps.

        """
        As=np.zeros((self.NnWOb,m))
        As.T[0]=a0     
        for i in range (m-1):
            sec_membre=F.T[i]-K@As.T[i]
            dAdt=spsolve(M,sec_membre.T)
            As.T[i+1]=As.T[i]+pas*dAdt
        return coo_matrix(As)        
    def oper_proj(self,As):
        """
        Description
        -----------
        Calcul de l'opérateur de projection P à partir des résultats des snapshots.
    
        Parameters
        ----------
        As : array([NnWOb,m])
            Matrice contenant les résultats de la résolution des m premiers pas 
            de temps.

        Returns
        -------
        P : array([NnWOb,r]) avec r est la taille réduite du problème

        """
        u,s,v = np.linalg.svd(As.toarray())
        sfiltr=np.zeros(len(s))
        j=0
        for i in range(len(s)):
            if s[i]>self.Tol_proj:
                sfiltr[j]=s[i]
                j=j+1
        sigma=np.zeros(j)
        for i in range(j):
            sigma[i]=sfiltr[i]        
        P=np.zeros((As.shape[0],j))
        for i in range (j):
            P.T[i]=s[i]*u.T[i]
        return coo_matrix(P)
    def reduc(K,M,F,P):
        """
        Description
        -----------
        Réduction des données du problème pour construire le système réduit 
        à résoudre

        Parameters
        ----------
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        F : array([NnWOb,Ntemps])
            Matrice telle que ces chaque colonne correspond au second membre du
            système pour un instant donné ( t(i)=i.pas pour i=0 à Ntemps-1 ).
        P : array([NnWOb,r]) 
            avec r est la taille réduite du problème

        Returns
        -------
        Kr : array([r,r])
            Matrice de rigidité.
        Mr : array([r,r])
            Matrice de masse.
        Fr : array([r,Ntemps])
            Matrice telle que ces chaque colonne correspond au second membre du
            système pour un instant donné ( t(i)=i.pas pour i=0 à Ntemps-1 ).

        """
        Kr=P.T@K@P
        Mr=P.T@M@P
        Fr=P.T@F
        return (Kr,Mr,Fr)    
    def solve_reduc(self,Mr,Nr,Fr,ar0,Tf,pas,P):
        """
        Description
        -----------
        Résolution du système réduit avec la méthode d'Euler et le calcul de 
        la solution du problème initial

        Parameters
        ----------
        Kr : array([r,r])
            Matrice de rigidité.
        Mr : array([r,r])
            Matrice de masse.
        Fr : array([r,Ntemps])
            Matrice telle que ces chaque colonne correspond au second membre du
            système pour un instant donné ( t(i)=i.pas pour i=0 à Ntemps-1 ).
        ar0 : array([r])
            Condition initiale du problème réduit, elle est exprimée en fonction
            de la condition initiale du problème initial tel que: 
                ar0 = transpose(P).a0 
        T : int
            Temps final.
        pas : float
            le pas du schéma d'Euler. pas= Tfin/(Ntemps-1)
        P : array([NnWOb,r]) 
            avec r est la taille réduite du problème

        Returns
        -------
        Ad : array([NnWOb,Ntemsp])
            Solution du Problème initial.

        """
        Ar=np.zeros((Mr.shape[0],self.Ntemps))
        Ar.T[0]=ar0
        for i in range (self.Ntemps-1):
            sec_membre=Fr.T[i]-Mr@Ar.T[i]
            dAdt=spsolve(Nr,sec_membre.T)
            Ar.T[i+1]=Ar.T[i]+pas*dAdt
        Ad=P@Ar    
        return Ad

    def calcul(self,Triangles,PreCalcul,source,K,M,a0,m):
        """
        Description
        -----------
        Procédure de la méthode POD

        Parameters
        ----------
        Triangles : Type Triangles
            Cette classe permet de récupérer les informations des triangles du maillage..
        PreCalcul : Liste
            Liste de Tuple contenant différents calculs pour chaque triangle.
        source : array([Nn,Ntemps])
            Matrice contenant les valeurs de la source pour chaque noeuds pour
            chaque pas de temps.
        K : array([NnWOb,NnWOb])
            Matrice de rigidité.
        M : array([NnWOb,NnWOb])
            Matrice de masse.
        a0 : array([NnWOb])
            Condition initiale du schéma d'Euler.
        m : int
            le nombre de Snapshot.

        Returns
        -------
        T : array([Nn,Ntemps])
            Solution du problème: une matrice qui contient les valeurs de la
            solution pour chaque noeuds pour chaque pas de temps.

        """
        ti=process_time()
        F = M@source
        As=POD.snapshot(self,K, M, F, a0, m, self.dt)
        P=POD.oper_proj(self,As)
        (Kr,Mr,Fr)=POD.reduc(K, M, F, P)
        ar0=P.T@a0
        self.TailleReduc = P.shape
        Ad=POD.solve_reduc(self,Kr, Mr, Fr, ar0, self.Tfin, self.dt, P)
        self.TpsCalcul=process_time()-ti
        self.sol=Ad
        