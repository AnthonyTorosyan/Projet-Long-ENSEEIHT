# -*- coding: utf-8 -*-
"""
Created on Thu Feb 16 14:27:37 2023

@author: yacoubi/arabej
"""

import gmsh
import sys


# Initialiser GMSH
gmsh.initialize(sys.argv)
# Demander à GMSH d'afficher des informations dans le terminal
gmsh.option.setNumber("General.Terminal", 1)

# Créer un modèle et le nommer "MySquare"
model = gmsh.model
model.add("MySquare2")


# Paramètres
L1 = 1 # Taille du grand carré
L2 = 0.5 # Taille du petit carré
h = 0.01 # Taille de maillage

# Créer 4 points pour les coins du grand carré
points_1 = []
points_1.append(model.geo.addPoint(-L1/2, 0, 0, h))
points_1.append(model.geo.addPoint(-L1/2, L1/2, 0, h))
points_1.append(model.geo.addPoint(L1/2, L1/2, 0, h))
points_1.append(model.geo.addPoint(L1/2, -L1/2, 0, h))
points_1.append(model.geo.addPoint(0, -L1/2, 0, h))
points_1.append(model.geo.addPoint(0, 0, 0, h))
points_1.append(model.geo.addPoint(-L1/2, 0, 0, h))
points_1.append(model.geo.addPoint(-L1/2, L1/2, 0, h))
# Créer 4 points pour les coins du petit carré
points_2 = []
points_2.append(model.geo.addPoint(-L1/2, -L1/2, 0, h))
points_2.append(model.geo.addPoint(-L1/2, 0, 0, h))
points_2.append(model.geo.addPoint(0, 0, 0, h))
points_2.append(model.geo.addPoint(0, -L1/2, 0, h))

# Créer 6 lignes pour les côtés du grand  carré
lines1 = []
for j in range(6):
  lines1.append(model.geo.addLine(points_1[j],points_1[(j+1)%6]))
# Créer 4 lignes pour les côtés du petit  carré
lines2 = []
for j in range(4):
  lines2.append(model.geo.addLine(points_2[j],points_2[(j+1)%4]))  
  
# Boucle de courbe et surface pour le grand carre
curveloop1 = model.geo.addCurveLoop(lines1)
square1 = model.geo.addPlaneSurface([curveloop1])  
# Boucle de courbe et surface pour le petit carre
curveloop2 = model.geo.addCurveLoop(lines2)
square2 = model.geo.addPlaneSurface([curveloop2]) 

# # Groupes physiques pour le grand carre
model.addPhysicalGroup(1, lines1, 1)
model.addPhysicalGroup(2, [square1], 2)
# Groupes physiques pour le petit carre
model.addPhysicalGroup(1, lines2, 3)
model.addPhysicalGroup(2, [square2], 4)







# Cette commande est obligatoire et synchronise CAD avec le modèle GMSH. Plus vous la lancez, moins c'est bon pour les performances.
model.geo.synchronize()
# Maillage (2D)
model.mesh.generate(2)
# Écrire sur le disque
gmsh.write("MySquare2.msh")
# Lancer l'interface graphique (pas obligatoire du tout)
gmsh.fltk.run();
# Finaliser GMSH
gmsh.finalize()