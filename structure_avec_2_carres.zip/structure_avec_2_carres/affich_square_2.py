# -*- coding: utf-8 -*-
"""
Created on Thu Feb 16 10:42:28 2023

@author: yacoubi/arabej
"""


import numpy as np
import gmsh
import gmsh_api
# Initialiser GMSH
gmsh.initialize()

# Ouvrir le fichier de maillage
model = gmsh.model
gmsh.open("MySquare2.msh")

# Récupérer les identifiants des entités de dimension 2 appartenant au groupe physique 4
entities = gmsh.model.getEntitiesForPhysicalGroup(2, 4)

triangles=[]
for tag in entities:
    node_indices,nodes_cords,vide=gmsh.model.mesh.getNodes(2, tag)
    # Regrouper les nœuds par groupes de 3 pour chaque triangle
    for i in range(0, len(node_indices), 3):
        triangle_nodes = node_indices[i:i+3]
        triangle_coords = nodes_cords[i:i+9] 
        triangles.append((triangle_nodes,triangle_coords))
                            
        
# # Afficher les résultats
# print(triangles)    
# Finaliser GMSH
gmsh.finalize()



