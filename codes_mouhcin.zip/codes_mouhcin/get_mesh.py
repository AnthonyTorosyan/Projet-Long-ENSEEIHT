# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 13:42:49 2023

@author: arabej
"""

import gmsh
import numpy as np

# Initialiser GMSH
# gmsh.initialize()

# Charger un fichier .msh
gmsh.open("MySquare.msh")

# Récupérer les noeuds
nodes = np.array(gmsh.model.mesh.getNodes()[1])

# Récupérer les éléments
elements = np.array(gmsh.model.mesh.getElements()[2])

# Finaliser GMSH
gmsh.finalize()
