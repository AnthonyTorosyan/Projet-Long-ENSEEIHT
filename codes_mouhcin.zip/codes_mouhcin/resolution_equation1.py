# -*- coding: utf-8 -*-
"""
Created on Thu Feb  9 14:27:48 2023

@author: arabej
"""

import numpy as np
from scipy.integrate import solve_ivp
from scipy.integrate import odeint
import matplotlib.pyplot as plt

#methode d'euler
def ode_func(t, y, Ar, Br):
    return (Cs/Br) - (Ar/Br)*y

Ar = ... # un scalaire
Br = ... # un scalaire
Cs = np.array([...])

t = np.linspace(0, 10, 100)
h = t[1] - t[0]
y0 = np.ones(len(Cs))

y = np.zeros((len(Cs), len(t)))
y[:, 0] = y0

for i in range(1, len(t)):
    y[:, i] = y[:, i-1] + h*ode_func(t[i-1], y[:, i-1], Ar, Br)

for i in range(len(Cs)):
    plt.plot(t, y[i, :], '-b', label=f'y{i+1}(t)')

plt.xlabel('t')
plt.ylabel('y(t)')
plt.legend()
plt.show()

#methode de runge_kutta
def ode_func(t, y, Ar, Br):
    return (Cs/Br) - (Ar/Br)*y

Ar = ... # un scalaire
Br = ... # un scalaire
Cs = np.array([...])


t = np.linspace(0, 10, 100)
h = t[1] - t[0]
y0 = np.ones(len(Cs))

y = np.zeros((len(Cs), len(t)))
y[:, 0] = y0

for i in range(1, len(t)):
    k1 = h*ode_func(t[i-1], y[:, i-1], Ar, Br)
    k2 = h*ode_func(t[i-1]+h/2, y[:, i-1]+k1/2, Ar, Br)
    k3 = h*ode_func(t[i-1]+h/2, y[:, i-1]+k2/2, Ar, Br)
    k4 = h*ode_func(t[i], y[:, i-1]+k3, Ar, Br)
    
    y[:, i] = y[:, i-1] + (k1 + 2*k2 + 2*k3 + k4)/6

for i in range(len(Cs)):
    plt.plot(t, y[i, :], '-b', label=f'y{i+1}(t)')

plt.xlabel('t')
plt.ylabel('y(t)')
plt.legend()
plt.show()

# methode  solve_ivp DE scipy.integrate qui utilise une méthode de collocation adaptative
#Définir la fonction de l'équation différentielle
def ode_func(t, y, Ar, Br, Cs):
    # La formule pour résoudre l'équation différentielle est donnée
    return (Cs/Br) - (Ar/Br)*y

# Définir les valeurs des constantes Ar, Br et Cs
Ar = ... # un scalaire
Br = ... # un scalaire
Cs = np.array([...])

# Générer une séquence de temps t allant de 0 à 10 avec 100 échantillons
t = np.linspace(0, 10, 100)

# Définir les conditions initiales y0 pour chaque élément de Cs
y0 = np.ones(len(Cs))

# Résoudre l'équation différentielle à l'aide de la méthode solve_ivp de SciPy
sol = solve_ivp(fun=lambda t, y: ode_func(t, y, Ar, Br, Cs),
                t_span=[t[0], t[-1]],
                y0=y0,
                t_eval=t)

# Tracer les solutions pour chaque élément de Cs
for i in range(len(Cs)):
    plt.plot(sol.t, sol.y[i, :], '-b', label=f'y{i+1}(t)')
plt.xlabel('t')
plt.ylabel('y(t)')
plt.legend()
plt.show()


#methode odeint de scipy.integrate qui utilise la méthode de Runge-Kutta
def ode_func(y, t, Ar, Br, Cs):
    return (Cs/Br) - (Ar/Br)*y

Ar = ... # un scalaire
Br = ... # un scalaire
Cs = np.array([...])

t = np.linspace(0, 10, 100)
y0 = np.ones(len(Cs))
sol = odeint(ode_func, y0, t, args=(Ar, Br, Cs))

for i in range(len(Cs)):
    plt.plot(t, sol[:, i], '-b', label=f'y{i+1}(t)')

plt.xlabel('t')
plt.ylabel('y(t)')
plt.legend()
plt.show()

