# -*- coding: utf-8 -*-
"""
Created on Wed Feb  8 20:57:14 2023

@author: antho
"""

from Maillage import Mesh,Triangles
from EDP import EDPsca
from Resolution import PGD
import numpy as np
from scipy.sparse import coo_matrix
from numpy.linalg import norm
from plot_test import *

###################################################################################
"""

"""
###################################################################################
"""
PRE-TRAITEMENT (A COMPILER UNE SEULE FOIS)
"""
# Récupération du maillage et précalcul 
Maill = Mesh("MySquare.msh")
Tri = Triangles(Maill.Noeuds,Maill.Coord,Maill.NoeudsNotBoundary)
PC = Tri.PreCalcul()
# Définition de l'équation aux dérivées partielles 
EquChaleur = EDPsca()
EquChaleur.C1(1.0)
EquChaleur.C2(1.0)
EquChaleur.Operateur("LaplacienScalaire")
# Création des matrices de masse et de rigidité
M = EquChaleur.Masse(Tri,PC)
K = EquChaleur.Rigidité(Tri,PC)
# Création de la source
EquChaleur.TypeSource = "Constante"
Amplitude = 1.0
Source = EquChaleur.Source(Amplitude)
###################################################################################
"""
PROPER ORTHOGONAL DECOMPOSITION
"""

###################################################################################
"""
PROPER GENERALIZED DECOMPOSITION
# """
RES = PGD(Tri,1.0,1000,1,1e-3,1e-3)
# RES.Tfin = 5e-3; RES.Ntemps = 100; RES.Mode = 5; RES.Rtol = 1e-3; RES.Stol = 1e-3
RES.Calcul(Tri,Source,PC,K,M,EquChaleur.C1,EquChaleur.C2)
###################################################################################
"""
POST-TRAITEMENT
"""
T = np.zeros([Tri.NnWOb,RES.Ntemps])
for i in range(RES.Ntemps):
    T[:,i] = RES.Rtot@RES.Stot[i,:]
Ttot = np.zeros([Tri.Nn,RES.Ntemps])
for i in range(RES.Ntemps):
    Ttot[Tri.Nn-Tri.NnWOb:Tri.Nn,i] = T[:,i]

result_plot(Ttot,Maill,500)