# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 13:33:40 2023

@author: arabej
"""
import gmsh
import sys

# Initialiser GMSH
gmsh.initialize(sys.argv)
# Demander à GMSH d'afficher des informations dans le terminal
gmsh.option.setNumber("General.Terminal", 1)

# Créer un modèle et le nommer "MySquare"
model = gmsh.model
model.add("MySquare")

# Paramètres
L = 1 # Taille du côté
h = 1e-2 # Taille de maillage

# Créer 4 points pour les coins du carré
points = []
points.append(model.geo.addPoint(-L/2, -L/2, 0, h))
points.append(model.geo.addPoint(L/2, -L/2, 0, h))
points.append(model.geo.addPoint(L/2, L/2, 0, h))
points.append(model.geo.addPoint(-L/2, L/2, 0, h))

# Créer 4 lignes pour les côtés du carré
lines = []
for j in range(4):
  lines.append(model.geo.addLine(points[j],points[(j+1)%4]))

# Boucle de courbe et surface
curveloop = model.geo.addCurveLoop(lines)
square = model.geo.addPlaneSurface([curveloop])

# Groupes physiques
# model.addPhysicalGroup(1, lines, 1)
# model.addPhysicalGroup(2, [square], 1)

# Cette commande est obligatoire et synchronise CAD avec le modèle GMSH. Plus vous la lancez, moins c'est bon pour les performances.
model.geo.synchronize()
# Maillage (2D)
model.mesh.generate(2)

elementOrder = 1
interpolationOrder = 2
gmsh.model.mesh.setOrder(elementOrder)

elementTypes = gmsh.model.mesh.getElementTypes()
def pp(label, v, mult):
    print(" * " + str(len(v) / mult) + " " + label + ": " + str(v))
elementTypes = gmsh.model.mesh.getElementTypes()
for t in elementTypes:
    elementName, dim, order, numNodes, numPrimNodes, localNodeCoord =\
    gmsh.model.mesh.getElementProperties(t)
    print("\n** " + elementName + " **\n")
    localCoords, weights =\
    gmsh.model.mesh.getIntegrationPoints(t, "Gauss" + str(interpolationOrder))
    pp("integration points to integrate order " + str(interpolationOrder) + " polynomials", localCoords, 3)
    numComponents, basisFunctions, numOrientations =\
    gmsh.model.mesh.getBasisFunctions(t, localCoords, "Lagrange")
    pp("basis functions at integration points", basisFunctions, 1)
    numComponents, basisFunctions, numOrientations =\
    gmsh.model.mesh.getBasisFunctions(t, localCoords, "GradLagrange")
    pp("basis function gradients at integration points", basisFunctions, 3)
# Écrire sur le disque
gmsh.write("MySquare.msh")
# Lancer l'interface graphique (pas obligatoire du tout)
gmsh.fltk.run();
# Finaliser GMSH
gmsh.finalize()

