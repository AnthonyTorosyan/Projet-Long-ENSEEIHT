# -*- coding: utf-8 -*-
"""
Created on Wed Feb  8 10:51:07 2023

@author: mehdi
"""

import numpy as np
import scipy as sp
import pod
from Assemblage import *
from Maillage import *

#---------------------------------------------------------------------------
# Définition du maillage
Maill = Mesh("MySquare.msh")
Tri = Triangles(Maill.Noeuds,Maill.Coord)
PC = Tri.PreCalcul()
# Définition de l'assemblage 
AssM = Assemblage(1,0,0)
AM = AssM.FaireAssemblage(Tri,PC)
M = AM.toarray()
AssN = Assemblage(0, 1, 0)
AN =AssN.FaireAssemblage(Tri, PC)
N = AN.toarray()
shape = np.shape(M)
#----------------------------------------------------------------------------
m=3
T=10
pas=1
F=np.ones((shape[0],int(T/pas)))
A0=20*np.ones((1, shape[0]))
#-----------------------------------------------------------------------------
#Résolution 
As=pod.snapshot(M, N, F, A0, m, pas)
P=pod.oper_proj(As)
(Mr,Nr,Fr)=pod.reduc(M, N, F, P)
ar0 = 20*np.ones((1, len(Mr)))
Ad = pod.solve_reduc(Mr, Nr, Fr, ar0, T, pas, P)


